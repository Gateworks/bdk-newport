/** @file example_register_sweep.c
 *****************************************************************************
 *
 * @brief
 *    This module provides an example of how to sweep the entire register set
 *    to ensure that the bits may be written correctly.
 *
 *****************************************************************************
 * @author
 *    Copyright (c) 2011-2015, Inphi Corporation
 *    All rights reserved.
 *    
 *    Redistribution and use in source and binary forms, with or without modification, 
 *    are permitted provided that the following conditions are met:
 *    
 *    1.	Redistributions of source code must retain the above copyright notice, 
 *       this list of conditions and the following disclaimer.
 *    
 *    2.	Redistributions in binary form must reproduce the above copyright notice, 
 *       this list of conditions and the following disclaimer in the documentation and/or 
 *       other materials provided with the distribution.
 *    
 *    3.	Neither the name of Inphi Corporation nor the names of its contributors 
 *       may be used to endorse or promote products derived from this software without 
 *       specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 *    THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 *    PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *    CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 *    PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 *    OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 *    WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 *    OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 *    ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *    API Version Number: 3.7.8
 ****************************************************************************/
#include "cs4224_api.h"

/**
 * Validate write access to a particular register by performing a walking
 * 1's and 0's test.
 *
 * @param slice         [I] - The slice of the device being accessed.
 * @param addr          [I] - The address of the register being accessed.
 * @param bitmask       [I] - A bitmask to mask out the read-only fields.
 * @param show_progress [I] - TRUE if progress messages should be displayed,
 *                            FALSE 
 *
 * @return CS_OK on success, CS_ERROR on failure.
 */
cs_status cs4224_validate_reg_writes(
    cs_uint32  slice,
    cs_uint32  addr,
    cs_uint16  bitmask,
    cs_boolean show_progress)
{
    cs_status status = CS_OK;

    cs_uint16 saved_value = 0;
    cs_uint16 new_value = 0;
    int i;

    /* Read the current value to save it for restoration */
    status |= cs4224_reg_get_channel(slice, addr, &saved_value);

    /* Perform a walking 1's test */
    if(show_progress)
    {
        CS_PRINTF(("Walking 1's test on %x\n", addr));
    }

    for(i = 0; i < 16; i++)
    {
        cs_uint16 pattern = 1 << i;

        /* Only do the test if we're hitting a writable bit */
        if((1<<i) == ((1<<i) & bitmask))
        {
            status |= cs4224_reg_set_channel(slice, addr, pattern);
            status |= cs4224_reg_get_channel(slice, addr, &new_value);
            if(show_progress)
            {
                CS_PRINTF(("  - wrote %x, read %x\n", pattern, new_value));
            }

            if(!((new_value & bitmask) == (pattern & bitmask)))
            {
                CS_PRINTF(("    - failed walking 1's on bit %d of %x\n", i, addr));
                return CS_ERROR;
            }
        }
        else
        {
            if(show_progress)
            {
                CS_PRINTF(("  - skipping bit %d - not writable\n", i));
            }
        }
    }

    /* Perform a walking 0's test */
    if(show_progress)
    {
        CS_PRINTF(("Walking 0's test on %x\n", addr));
    }

    for(i = 0; i < 16; i++)
    {
        cs_uint16 pattern = ~(1<<i);
        
        /* Only do the test if we're hitting a writable bit */
        if((1<<i) == ((1<<i) & bitmask))
        {
            status |= cs4224_reg_set_channel(slice, addr, pattern & bitmask);
            status |= cs4224_reg_get_channel(slice, addr, &new_value);
            if(show_progress)
            {
                CS_PRINTF(("  - wrote %x, read %x\n", pattern & bitmask, new_value));
            }

            if(!((new_value & bitmask) == (pattern & bitmask)))
            {
                CS_PRINTF(("    - failed walking 0's on bit %d of %x\n", i, addr));
                return CS_ERROR;
            }
        }
        else
        {
            if(show_progress)
            {
                CS_PRINTF(("  - skipping bit %d\n", i));
            }
        }
    }

    /* Now restore the original data */
    status |= cs4224_reg_set_channel(slice, addr, saved_value);

    return status; 
}


/** 
 * This method performs a sweep of the entire register set. It
 * performs a write test to ensure that the bits may be written
 * correctly and then restores the original value. This is a
 * destructive test in that the chip must be re-initialized after the
 * test is performed.
 * 
 * @param slice         [I] - The slice of the device being accessed.
 * @param show_progress [I] - TRUE if progress messages should be displayed,
 *                            FALSE 
 *
 * @return CS_OK on success, CS_ERROR on failure.
 */
cs_status example_register_sweep(
    cs_uint32  slice,
    cs_boolean show_progress)
{
    cs_status status = CS_OK;
    cs_uint32 die;

    /* Reset the ASIC to put it into a known state */
    cs4224_hard_reset(slice);
    CS_MDELAY(1000);

    die = cs4224_get_die_from_slice(slice);
    
    /* Use broadcast to enable all the clocks */
    status |= cs4224_reg_set(die, CS4224_GLOBAL_BROADCAST, 0x80);
    status |= cs4224_reg_set(die, CS4224_PP_LINE_LINEMISC_CLKEN,              0xFFFF);
    status |= cs4224_reg_set(die, CS4224_PP_LINE_LINEMISC_MPIF_RESET_DOTREG,  0);
    status |= cs4224_reg_set(die, CS4224_PP_LINE_LINEMISC_GIGEPCS_SOFT_RESET, 0);
    status |= cs4224_reg_set(die, CS4224_PP_LINE_SDS_DSP_MSEQ_POWER_DOWN_LSB, 0x0000);
    status |= cs4224_reg_set(die, CS4224_PP_LINE_SDS_DSP_MSEQ_POWER_DOWN_MSB, 0x0000);
    status |= cs4224_reg_set(die, CS4224_GLOBAL_BROADCAST,                    0x0);

    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0002, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0003, 0x001f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0004, 0x001f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0005, 0x001f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0006, 0x001f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0007, 0x001f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0008, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0009, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x000a, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0011, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0014, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0015, 0x0f01, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0018, 0x0003, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0019, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x001a, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x001b, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x001c, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x001d, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x001e, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x001f, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0020, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0021, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0022, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0023, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0024, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0027, 0x003f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0029, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x00fe, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0100, 0x0ff3, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0101, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0102, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0104, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0105, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0106, 0x0ff3, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0107, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0108, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x010a, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x010b, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x010c, 0x0ff3, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x010d, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x010e, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0110, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0111, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0112, 0x0ff3, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0113, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0114, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0116, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0117, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0118, 0x0ff3, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0119, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x011a, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x011c, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x011d, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x011e, 0x0007, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x011f, 0x0007, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0120, 0x0007, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0121, 0x0007, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0122, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0123, 0x1fff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0125, 0x001f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0129, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x012b, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x012f, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0133, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0137, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x013b, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x013f, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0143, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0147, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x014b, 0x001f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x02e0, 0x007f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x02e1, 0x0f13, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x02e2, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x02e6, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x02e7, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x02e8, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x02e9, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0300, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0304, 0x0007, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x0307, 0x0003, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x030a, 0x0003, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x030c, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x030d, 0x3fff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x030e, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1008, 0x0003, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1009, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x100a, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x100b, 0xf183, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x100c, 0x0007, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x100d, 0x0003, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x100e, 0x83ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1010, 0x0007, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1012, 0x3f3f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1020, 0x001d, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1021, 0x18ed, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1022, 0x0007, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1023, 0xff7f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1024, 0xf7ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1025, 0x0003, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1026, 0x07f3, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1027, 0xc0ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1028, 0x3f03, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1029, 0x0007, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x102a, 0x0077, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x102b, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x102c, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x102d, 0x0f00, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x102e, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x102f, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1030, 0x000c, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1031, 0x0fff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1032, 0xe07f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1033, 0xe0ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1034, 0x007f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1035, 0x007f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1038, 0x0fff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1039, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x103a, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x103b, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x103c, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x103d, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x103e, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x103f, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1040, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1041, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1042, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1043, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1044, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1045, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1046, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1047, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1048, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1049, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x104a, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x104b, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x104c, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x104d, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x104e, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x104f, 0x1f1f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1053, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1055, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1056, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1057, 0x0007, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1058, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1059, 0x7fff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x105a, 0xffbf, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x105d, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x105f, 0x0073, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1062, 0x7f03, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1063, 0x7f7f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1064, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1065, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1066, 0x000f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1067, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x106a, 0xff0f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x106c, 0xff0f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x106e, 0x0003, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x106f, 0xff75, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1070, 0xff1f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1075, 0x0007, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1077, 0x0f03, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1078, 0x0706, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1079, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x107a, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x107d, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x107e, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1081, 0x000f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1082, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1083, 0x060a, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1084, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1085, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1086, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1087, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1088, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1089, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x108a, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x108b, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x108c, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x108d, 0x3131, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x108e, 0x001f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1091, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1092, 0xf0ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1093, 0x0007, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1094, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1096, 0xff77, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1097, 0x000f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1098, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1099, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x109a, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x109b, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x109c, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x109d, 0x0003, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x109e, 0x003f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x109f, 0x1000, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x10a0, 0x000b, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x10a1, 0x0007, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x10a2, 0xe0f0, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x10a3, 0x000f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x10a4, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x10a5, 0x0007, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x10a6, 0x010f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x10a7, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x10a8, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x10a9, 0x1fff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x10aa, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x10ab, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x10ac, 0xf13f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x10ad, 0x000f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x10ae, 0x1f73, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x10af, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x10b0, 0x00f0, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x10b1, 0x3fff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x10b2, 0x7ff7, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x10b3, 0x0003, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x10b4, 0x0f7c, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x10b5, 0x0707, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x10b6, 0x0707, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x10b7, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x10b8, 0xf7f1, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x10b9, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x10bb, 0x0c0f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x10bd, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x10c0, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x10c3, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x10c5, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x10c8, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x10ca, 0x0001, show_progress)){return CS_ERROR;}
    /* 0x1220 is too complicated, certain values will cause an MDIO timeout */
    /*if(CS_OK != cs4224_validate_reg_writes(slice, 0x1220, 0xffff, show_progress)){return CS_ERROR;}*/
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1221, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1222, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1225, 0x000f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1228, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1234, 0x007f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1238, 0x0007, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1239, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x123a, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x123b, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x123c, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x123e, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x123f, 0x000f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1240, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1243, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1244, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1249, 0x0003, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x124e, 0x0fff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1250, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1251, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1252, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1253, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1254, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1255, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1256, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1257, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1258, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1259, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x125a, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x125b, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x125c, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x125d, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x125e, 0x0f0f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x125f, 0x070f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1261, 0x0f3f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1262, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1263, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1264, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1265, 0x003f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1266, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1267, 0x0fff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1268, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1269, 0x003f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x126a, 0x7fff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x126b, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x126c, 0x0003, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1273, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1274, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1275, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1280, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1281, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1282, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1283, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1284, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1285, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1286, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1287, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1288, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1289, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x128a, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x128b, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x128c, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x128d, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x128e, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x128f, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1290, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1291, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1292, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1293, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1294, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1295, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1296, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1297, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1298, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1299, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x129a, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x129b, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x129c, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x129d, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x129e, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x129f, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x12a0, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x12a1, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x12a2, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x12a3, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x12a4, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x12a5, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x12a6, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x12a7, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x12a8, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x12a9, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x12aa, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x12ab, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x12ac, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x12ad, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x12ae, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x12af, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x12b0, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x12b1, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x12b2, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x12b3, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x12b4, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x12b5, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x12b6, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x12b7, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x12b8, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x12b9, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1320, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1321, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1322, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1323, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1324, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1325, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1326, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1327, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1328, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1329, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x132a, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x132b, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x132c, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x132d, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x132e, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x132f, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1330, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1331, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1332, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1333, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1334, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1335, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1336, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1337, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1338, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1339, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x133a, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x133b, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x133c, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x133d, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x133e, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x133f, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1340, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1341, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1342, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1343, 0x000f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1344, 0x0008, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1345, 0x0002, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1355, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1357, 0x0007, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1358, 0x000f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x135b, 0x1f0f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x135c, 0x1f1f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1420, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1421, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1422, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x142e, 0xdf87, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x142f, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1430, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1431, 0x7f7f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1432, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1433, 0x3f3f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1434, 0x007f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1435, 0x000f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1436, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1437, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1438, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x143a, 0x0003, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1441, 0x7f01, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1442, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1460, 0x5c10, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1472, 0xfffe, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1473, 0x001f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1481, 0x0f1f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x14a0, 0x8003, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x14a3, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x14a5, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x14b0, 0x8031, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x14b1, 0x03ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x14b2, 0x03ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x14b3, 0x03ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x14b4, 0x03ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x14b6, 0x0003, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x14b8, 0x001f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x14c0, 0x800b, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x14c1, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x14c2, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x14c3, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x14c4, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x14e0, 0xd089, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x14e4, 0x0700, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x14ed, 0xff3f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x14ee, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x14ef, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1500, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1501, 0x0003, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1503, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1507, 0x0003, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x150c, 0x3c7f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x150d, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x150e, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x150f, 0x0007, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1511, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1512, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1513, 0x000f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1514, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1515, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1516, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1517, 0x0fff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1518, 0x007e, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x151d, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x151e, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x151f, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1520, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1521, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1522, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1523, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1524, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1525, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1526, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1527, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1528, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1529, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x152a, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x152b, 0x000f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x152e, 0x003f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1532, 0x0003, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1538, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1540, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1542, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1543, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1556, 0x007e, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1557, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1558, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x155b, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x155f, 0x0003, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1563, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1564, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1565, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1580, 0x0003, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1581, 0x0003, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1583, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1584, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1589, 0xc003, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x158c, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x158d, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x158e, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x158f, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1590, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1591, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1592, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1593, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1594, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1595, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1596, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1597, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1598, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1599, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x159a, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x159b, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x159c, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x159d, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x159e, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x159f, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x15a3, 0x0fff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x15a4, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x15a8, 0x07ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x15ab, 0xffcf, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x15ad, 0x7fff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x15ae, 0x7fff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x15af, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x15c0, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x15c1, 0x11ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x15c3, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x15c8, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x15cb, 0x01f1, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1600, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1601, 0x0700, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1603, 0x7f7f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1604, 0x3f3f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1605, 0x3f3f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1606, 0x003f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1607, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1608, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1609, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x160a, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x160e, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1640, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1641, 0x0706, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1643, 0x0f0f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1644, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x164f, 0xfffb, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1650, 0x0f0f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1651, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1652, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1653, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1654, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1655, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1656, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1657, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1658, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1659, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x165a, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x165b, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x165c, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x165d, 0x17ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x165e, 0x17ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1660, 0x0f1f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1664, 0x0003, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1680, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1682, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x168a, 0x7fff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x168b, 0xff81, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x168c, 0x000f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1808, 0x0003, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1809, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x180a, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x180b, 0xf180, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x180e, 0x83ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1810, 0x0006, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1812, 0x0007, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1820, 0x001d, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1821, 0x18ed, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1822, 0x0007, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1823, 0xff7f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1824, 0xf7ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1825, 0x0003, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1826, 0x07f3, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1827, 0xc0ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1828, 0x3f03, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1829, 0x0007, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x182a, 0x0077, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x182b, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x182c, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x182d, 0x0f00, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x182e, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x182f, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1830, 0x000c, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1831, 0x0fff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1832, 0xe07f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1833, 0xe0ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1834, 0x007f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1835, 0x007f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1838, 0x0fff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1839, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x183a, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x183b, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x183c, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x183d, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x183e, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x183f, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1840, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1841, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1842, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1843, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1844, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1845, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1846, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1847, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1848, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1849, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x184a, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x184b, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x184c, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x184d, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x184e, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x184f, 0x1f1f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1853, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1855, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1856, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1857, 0x0007, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1858, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1859, 0x7fff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x185a, 0xffbf, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x185d, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x185f, 0x0073, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1862, 0x7f03, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1863, 0x7f7f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1864, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1865, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1866, 0x000f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1867, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x186a, 0xff0f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x186c, 0xff0f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x186e, 0x0003, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x186f, 0xff75, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1870, 0xff1f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1875, 0x0007, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1877, 0x0f03, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1878, 0x0706, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1879, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x187a, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x187d, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x187e, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1881, 0x000f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1882, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1883, 0x060a, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1884, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1885, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1886, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1887, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1888, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1889, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x188a, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x188b, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x188c, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x188d, 0x3131, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x188e, 0x001f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1891, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1892, 0xf0ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1893, 0x0007, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1894, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1896, 0xff77, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1897, 0x000f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1898, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1899, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x189a, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x189b, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x189c, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x189d, 0x0003, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x189e, 0x003f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x189f, 0x1000, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x18a0, 0x000b, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x18a1, 0x0007, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x18a2, 0xe0f0, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x18a3, 0x000f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x18a4, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x18a5, 0x0007, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x18a6, 0x010f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x18a7, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x18a8, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x18a9, 0x1fff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x18aa, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x18ab, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x18ac, 0xf13f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x18ad, 0x000f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x18ae, 0x1f73, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x18af, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x18b0, 0x00f0, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x18b1, 0x3fff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x18b2, 0x7ff7, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x18b3, 0x0003, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x18b4, 0x0f7c, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x18b5, 0x0707, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x18b6, 0x0707, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x18b7, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x18b8, 0xf7f1, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x18b9, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x18bb, 0x0c0f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x18bd, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x18c0, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x18c3, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x18c5, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x18c8, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x18ca, 0x0001, show_progress)){return CS_ERROR;}
    /* 0x1a20 is too complicated, certain values will cause an MDIO timeout */
    /*if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a20, 0xffff, show_progress)){return CS_ERROR;}*/
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a21, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a22, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a25, 0x000f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a28, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a34, 0x007f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a38, 0x0007, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a39, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a3a, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a3b, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a3c, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a3e, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a3f, 0x000f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a40, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a43, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a44, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a49, 0x0003, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a4e, 0x0fff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a50, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a51, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a52, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a53, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a54, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a55, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a56, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a57, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a58, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a59, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a5a, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a5b, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a5c, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a5d, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a5e, 0x0f0f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a5f, 0x070f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a61, 0x0f3f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a62, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a63, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a64, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a65, 0x003f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a66, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a67, 0x0fff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a68, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a69, 0x003f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a6a, 0x7fff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a6b, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a6c, 0x0003, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a73, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a74, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a75, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a80, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a81, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a82, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a83, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a84, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a85, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a86, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a87, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a88, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a89, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a8a, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a8b, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a8c, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a8d, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a8e, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a8f, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a90, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a91, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a92, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a93, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a94, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a95, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a96, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a97, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a98, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a99, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a9a, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a9b, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a9c, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a9d, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a9e, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1a9f, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1aa0, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1aa1, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1aa2, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1aa3, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1aa4, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1aa5, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1aa6, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1aa7, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1aa8, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1aa9, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1aaa, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1aab, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1aac, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1aad, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1aae, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1aaf, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1ab0, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1ab1, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1ab2, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1ab3, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1ab4, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1ab5, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1ab6, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1ab7, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1ab8, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1ab9, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1b20, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1b21, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1b22, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1b23, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1b24, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1b25, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1b26, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1b27, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1b28, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1b29, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1b2a, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1b2b, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1b2c, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1b2d, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1b2e, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1b2f, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1b30, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1b31, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1b32, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1b33, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1b34, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1b35, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1b36, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1b37, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1b38, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1b39, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1b3a, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1b3b, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1b3c, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1b3d, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1b3e, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1b3f, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1b40, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1b41, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1b42, 0x01ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1b43, 0x000f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1b44, 0x0008, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1b45, 0x0002, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1b55, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1b57, 0x0007, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1b58, 0x000f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1b5b, 0x1f0f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1b5c, 0x1f1f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1c20, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1c21, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1c22, 0x0001, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1c2e, 0xdf87, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1c2f, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1c30, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1c31, 0x7f7f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1c32, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1c33, 0x3f3f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1c34, 0x007f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1c35, 0x000f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1c36, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1c37, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1c38, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1c3a, 0x0003, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1c41, 0x7f01, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1c42, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1c60, 0x5c10, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1c81, 0x0f1f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1d00, 0x007f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1d01, 0x0f13, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1d02, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1d06, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1d07, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1d08, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1d09, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1d10, 0x007f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1d11, 0x0f13, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1d12, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1d16, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1d17, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1d18, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x1d19, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x5004, 0x000f, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x5007, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x5009, 0x00ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x500a, 0x07ff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x500b, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x500d, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x500e, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x500f, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x5010, 0xffff, show_progress)){return CS_ERROR;}
    if(CS_OK != cs4224_validate_reg_writes(slice, 0x5011, 0xffff, show_progress)){return CS_ERROR;}


    /* Reset the slice again after the test */
    status |= cs4224_hard_reset(slice);

    return status;
}

