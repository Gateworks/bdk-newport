/** @file example_eye_monitor.c
 *****************************************************************************
 *
 * @brief
 *    This module provides an example of using the eye monitor.
 *
 *****************************************************************************
 * @author
 *    Copyright (c) 2011-2015, Inphi Corporation
 *    All rights reserved.
 *    
 *    Redistribution and use in source and binary forms, with or without modification, 
 *    are permitted provided that the following conditions are met:
 *    
 *    1.	Redistributions of source code must retain the above copyright notice, 
 *       this list of conditions and the following disclaimer.
 *    
 *    2.	Redistributions in binary form must reproduce the above copyright notice, 
 *       this list of conditions and the following disclaimer in the documentation and/or 
 *       other materials provided with the distribution.
 *    
 *    3.	Neither the name of Inphi Corporation nor the names of its contributors 
 *       may be used to endorse or promote products derived from this software without 
 *       specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 *    THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 *    PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *    CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 *    PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 *    OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 *    WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 *    OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 *    ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *    API Version Number: 3.7.8
 ****************************************************************************/
#include "cs4224_api.h"

/**
 * This method is called to load the collected samples from the Eye Monitor
 * in order to plot them on an eye diagram. This method can be used instead of
 * the built-in cs4224_emds_capture_file() method to capture data to internal
 * structures.
 *
 * @param emds  [I] - The Eye Monitor data structure.
 * @param samples [I] - The structure matrix to store sample data in
 * @param rotate [I] - The amount to rotate/shift the phase in order to center the eye opening
 *
 * @return CS_OK on success, CS_ERROR on failure.
 */
cs_status load_samples(cs4224_emds_config_t* emds,
                       cs4224_emds_sample_t samples[][128],
                       cs_int32 rotate)
{
    cs_status status = CS_OK;
    /*  used to check the status of the eye data fifo */
    cs_boolean done = 0;
    /* temporary sample data */
    cs4224_emds_sample_t new_sample;
    /* phase and voltage iterators */
    cs_int32 p = 0, v = 0;

    cs4224_emds_sample_init(&new_sample);
    
    /* check rotate bounds */
    if(rotate > 63 || rotate < 0)
    {
        CS_PRINTF(("Error: rotate out-of-bounds: rotate=%d\n", rotate));
        return CS_ERROR;
    }

    /* done represents whether there is still data to be captured or not */
    while(done == 0)
    {

        /* capture next sample */
        status |= cs4224_emds_sample_load_next(emds, &new_sample, &done);
        if ( status != CS_OK )
        {
            CS_PRINTF(("Error: emds config preventing the loading of samples\n"));
            return status;
        }

        /* if the sample is still valid... */
        if(done != 1)
        {
            /* ...get the sample coordinates, rotated by the correct amount... */
            p = new_sample.phase_coord;
            v = new_sample.voltage_coord;
            p -= rotate;
            if(p<0)
            {
                /* handle wrap-around */
                p = 64 + p;
            }

            if((v % 2) == 0)
            {
                /* full capture takes a long time, print a little status bar */
                CS_PRINTF(("."));
                CS_FLUSH();
            }
            /* ...and save the valid sample data into samples. */
            cs4224_emds_sample_init( &(samples[p][v]) );
            samples[p][v].valid         = 1;
            samples[p][v].no_sync       = new_sample.no_sync;
            /* use rotated phase instead of real/captured phase */
            samples[p][v].phase_coord   = p;
            samples[p][v].voltage_coord = new_sample.voltage_coord;
            samples[p][v].time          = new_sample.time;
            samples[p][v].err_cnt       = new_sample.err_cnt;
            samples[p][v].sat_reached   = new_sample.sat_reached;
        }
    }
    CS_PRINTF(("\n"));

    return status;
}


/**
 * The following example describes the process of capturing the full eye data to
 *  a file called 'eye.data'.
 * 
 * NOTE: there is no setup information here, it assumes the board is already configured with active
 * traffic (>8G speeds)
 */
cs_status example_eye_monitor()
{
    cs_status status = CS_OK;

    /* Test the eye monitor code here */
    {
        /* The relative height of the eye (0-127) */
        int height;
        /* The relative width of the eye (0-63) */
        int width;
        /* The x-coordinate of the center of the eye */
        int x;
        /* The y-coordinate of the center of the eye */
        int y;
        /* The estimated eye height in units of voltage (0 - 1.0V) */
        cs_float volts;
        /* The estimated eye width in units of UI (0 - 1UI) */
        cs_float ui;
        /* The x-offset used to re-center the eye */
        int x_offset = 0;
        /* The y-offset used to re-center the eye */
        int y_offset = 0;
        /*  eye monitor config struct */
        cs4224_emds_config_t emds;

        /*  init emds config */
        cs4224_emds_config_init(&emds);
        /*  set configuration needed for cs4224_emds_enable */
        /*  note values are hw setup dependant */
        emds.slice          = 7;
        emds.interface      = CS4224_EMDS_LINE_INTERFACE;


        /*  enable eye monitor */
        status |= cs4224_emds_enable(&emds);

        /*  find eye phase center offset (optional, formats the eye plot nicely)
         *  see the user_guide for more info on phase_offset */
        /*  this method will overwrite the voltage/phase/period data in emds */
        status |= cs4224_emds_find_eye_dimensions(&emds, &x, &y, &width, &height, &volts, &ui);

        CS_PRINTF(("Eye Data\n"
                   "  x = %d, y = %d\n"
                   "  width = %d, height = %d\n",
                   x, y, width, height));
            
        status |= cs4224_emds_get_offsets_from_center(x, y, &x_offset, &y_offset, TRUE);

        CS_PRINTF(("  x-offset = %d, y_offset = %d\n", x_offset, y_offset));
            
        emds.phase_offset = x_offset;
        emds.voltage_offset = y_offset;

#   ifndef CS_DONT_USE_STDLIB
#     ifdef  CS_HAS_FILESYSTEM
        /* run through full sweep of the eye and save it to eye.data */
        status |= cs4224_emds_capture_file(&emds, "eye.data");
#     else
#       warning "WARNING: example_eye_monitor can't be run without filesystem support"
#     endif  /* CS_HAS_FILESYSTEM  */
#   else
#     warning "WARNING: example_eye_monitor can't be run without stdlib support"
#   endif  /* CS_DONT_USE_STDLIB */
    }

    return status;
}


/**
 * The following example describes the process capturing the eye height/width,
 *  without capturing all the eye data.
 * 
 * NOTE: there is no setup information here, it assumes the board is already configured with active
 * traffic (>8G speeds)
 */
cs_status example_eye_size()
{
    cs_status status = CS_OK;

    /* Test the eye monitor code here */
    {
        /*  eye monitor config struct */
        cs4224_emds_config_t emds;
        /* The relative height of the eye (0-127) */
        int height;
        /* The relative width of the eye (0-63) */
        int width;
        /* The x-coordinate of the center of the eye */
        int x;
        /* The y-coordinate of the center of the eye */
        int y;
        /* The estimated eye height in units of voltage (0 - 1.0V) */
        cs_float volts;
        /* The estimated eye width in units of UI (0 - 1UI) */
        cs_float ui;

        /*  init emds config */
        cs4224_emds_config_init(&emds);
    
        /*  set configuration needed for cs4224_emds_enable */
        /*  note values are hw setup dependant */
        emds.slice          = 7;
        emds.interface      = CS4224_EMDS_LINE_INTERFACE;
        

        /* Specify the sample period used to sample each point in
         * the eye monitor sweep. This can be tuned to determine
         * how long the eye is sampled at each point. A longer sampling
         * period will take longer to scan but will result in more
         * accurate results. */
        emds.period_base = CS4224_EMDS_PERIOD_BASE_100MS;
        emds.period_len = 1;

        /*  enable eye monitor */
        status |= cs4224_emds_enable(&emds);

        /* Determine the height and width of the eye in both
         * relative units and estimated voltage/UI */
        status = cs4224_emds_find_eye_dimensions(&emds, &x, &y, &width, &height, &volts, &ui);

        if(status == CS_ERROR)
        {
            CS_PRINTF(("  Error obtaining eye from slice %d\n", emds.slice));
            return CS_ERROR;
        }
        else
        {
            CS_PRINTF(("  Eye\n"));
            CS_PRINTF(("    Eye width: %d/64 (%f UI)  height: %d/128 (%f V)\n",width,ui,height,volts));
            CS_PRINTF(("    Eye Center: x = %d, y = %d\n",x, y));
        }
        CS_PRINTF(("\n"));
    }

    return status;
}


