/** @file example_link_ready.c
 *****************************************************************************
 *
 * @brief
 *    This module provides an example of checking the link ready status
 *
 *****************************************************************************
 * @author
 *    Copyright (c) 2011-2015, Inphi Corporation
 *    All rights reserved.
 *    
 *    Redistribution and use in source and binary forms, with or without modification, 
 *    are permitted provided that the following conditions are met:
 *    
 *    1.	Redistributions of source code must retain the above copyright notice, 
 *       this list of conditions and the following disclaimer.
 *    
 *    2.	Redistributions in binary form must reproduce the above copyright notice, 
 *       this list of conditions and the following disclaimer in the documentation and/or 
 *       other materials provided with the distribution.
 *    
 *    3.	Neither the name of Inphi Corporation nor the names of its contributors 
 *       may be used to endorse or promote products derived from this software without 
 *       specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 *    THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 *    PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *    CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 *    PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 *    OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 *    WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 *    OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 *    ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *    API Version Number: 3.7.8
 ****************************************************************************/
#include "cs4224_api.h"


/**
 * The following example describes the process of obtaining
 * the link status on multiple slices at once
 *
 * @return CS_OK on success, CS_ERROR on failure
 */
cs_status example_link_ready()
{
    cs_status status = CS_OK;

    /* if an interface isn't locked, this will tell you which one is having issues */
    cs_uint16  interface_fault = 0;
    /* true if all links are ready */
    cs_boolean links_ready = FALSE;
    
    /* There are two different examples here, one to check a few slices and one to check
     * all of them. We use a '#if' here to choose between them
     */
#if 0
    /* the number of interfaces to check */
    /* NOTE: duplex have 2 Rx interfaces per port (line/host) */
    cs_uint16  length = CS4224_MAX_NUM_CS4343_PORTS * 2;

    /* the interfaces var will list all the interfaces you want to check for lock */
    cs4224_interface_t interfaces[length];

    cs_uint16 i = 0;

    /* populate the interface list, in this case add everything */
    for(i = 0; i < length; i++)
    {
        /* each slice has a line and host Rx */
        interfaces[i].slice = i / 2;
        if(i%2)
        {
            interfaces[i].mseq_id = CS4224_DPLX_HOST_MSEQ;
        }
        else
        {
            interfaces[i].mseq_id = CS4224_DPLX_LINE_MSEQ;
        }
    }
#else
    /* the interfaces var will list all the interfaces you want to check for lock */
    cs4224_interface_t interfaces[] = { \
        { 6, CS4224_DPLX_LINE_MSEQ }, \
        { 6, CS4224_DPLX_HOST_MSEQ }, \
        { 7, CS4224_DPLX_LINE_MSEQ }, \
        { 7, CS4224_DPLX_HOST_MSEQ } \
    };

    /* always use automatic length determination to minimize bugs */
    cs_uint16 length = sizeof(interfaces)/sizeof(interfaces[0]);
#endif
    
    status |= cs4224_query_links_ready(interfaces, length, 500, &interface_fault, &links_ready);
    
    if(!links_ready)
    {
        cs_uint32 slice = interfaces[interface_fault].slice;
        e_cs4224_mseq_id mseq_id = interfaces[interface_fault].mseq_id;
        cs_char8  *side;
        
        if     (CS4224_DPLX_HOST_MSEQ == mseq_id) side = "HOST";
        else if(CS4224_DPLX_LINE_MSEQ == mseq_id) side = "LINE";
        else                                      side = "SPLX";
        
        CS_TRACE(("ERROR: Interface %x %s is not locked\n",slice,side));
        return CS_ERROR;
    }
    
    return CS_OK;
}


/**
 * The following example shows how to wait for a number of interfaces to lock
 * before sending data through the EDC
 *
 * @return CS_OK on success, CS_ERROR on failure
 */
cs_status example_wait_link_ready()
{
    /* There are two different examples here, one to check a few slices and one to check
     * all of them. We use a '#if' here to choose between them
     */
#if 0
    /* the number of interfaces to check */
    /* NOTE: duplex have 2 Rx interfaces per port (line/host) */
    cs_uint16  length = CS4224_MAX_NUM_CS4343_PORTS * 2;

    /* the interfaces var will list all the interfaces you want to check for lock */
    cs4224_interface_t interfaces[length];

    cs_uint16 i = 0;

    /* populate the interface list, in this case add everything */
    for(i = 0; i < length; i++)
    {
        /* each slice has a line and host Rx */
        interfaces[i].slice = i / 2;
        if(i%2)
        {
            interfaces[i].mseq_id = CS4224_DPLX_HOST_MSEQ;
        }
        else
        {
            interfaces[i].mseq_id = CS4224_DPLX_LINE_MSEQ;
        }
    }
#else
    /* the interfaces var will list all the interfaces you want to check for lock */
    cs4224_interface_t interfaces[] = { \
        { 6, CS4224_DPLX_LINE_MSEQ }, \
        { 6, CS4224_DPLX_HOST_MSEQ }, \
        { 7, CS4224_DPLX_LINE_MSEQ }, \
        { 7, CS4224_DPLX_HOST_MSEQ } \
    };

    /* always use automatic length determination to minimize bugs */
    cs_uint16 length = sizeof(interfaces)/sizeof(interfaces[0]);
#endif
    
    if(CS_OK != cs4224_wait_for_links_ready(interfaces, length, 500, 10000))
    {
        CS_TRACE(("ERROR: Interfaces are not locked, exiting...\n"));
        return CS_ERROR;
    }
    
    /* start traffic, etc... */
    
    return CS_OK;
}


