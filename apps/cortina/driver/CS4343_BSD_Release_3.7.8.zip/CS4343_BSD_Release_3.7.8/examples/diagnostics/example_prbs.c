/** @file example_prbs.c
 *****************************************************************************
 *
 * @brief
 *    This module provides an example of configuring the PRBS generator and 
 *    checker.
 *
 *****************************************************************************
 * @author
 *    Copyright (c) 2011-2015, Inphi Corporation
 *    All rights reserved.
 *    
 *    Redistribution and use in source and binary forms, with or without modification, 
 *    are permitted provided that the following conditions are met:
 *    
 *    1.	Redistributions of source code must retain the above copyright notice, 
 *       this list of conditions and the following disclaimer.
 *    
 *    2.	Redistributions in binary form must reproduce the above copyright notice, 
 *       this list of conditions and the following disclaimer in the documentation and/or 
 *       other materials provided with the distribution.
 *    
 *    3.	Neither the name of Inphi Corporation nor the names of its contributors 
 *       may be used to endorse or promote products derived from this software without 
 *       specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 *    THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 *    PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *    CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 *    PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 *    OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 *    WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 *    OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 *    ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *    API Version Number: 3.7.8
 ****************************************************************************/
#include "cs4224_api.h"

/**
 * The following example describes the process of configuring the PRBS
 * generator and checker.
 */

cs_status example_prbs()
{
    cs_status status = CS_OK;
    cs4224_rules_t rules;
    cs_uint32  prbs_error_count;
    cs_boolean prbs_sync;

    cs_uint32 slice;

    CS_PRINTF(("Initializing the chip in 10.3125G mode\n"));

    /* Provision all ports of the chip for 10.3125G mode. This
     * assumes:
     *   - Device configured for 156.25MHz reference clock
     *   - No fractional divider
     *   - Microcode programmed automatically if not
     *     already programmed via EEPROM.
     */ 
    status |= cs4224_rules_set_default(CS4224_TARGET_APPLICATION_10G, &rules);

    for(slice = 0; slice < CS4224_MAX_NUM_SLICES(0); slice++)
    {
        status |= cs4224_slice_enter_operational_state(slice, &rules);
    }

    CS_PRINTF(("Configuring the PRBS generator and checker\n"));

    
    /* configure the PRBS generator on slice 0 and
     * put it in PFD mode */
    status |= cs4224_diags_prbs_generator_set_pfd_mode(
                  0,
                  CS4224_PRBS_HOST_INTERFACE,
                  TRUE);

    status |= cs4224_diags_prbs_generator_config(
                  0,  
                  CS4224_PRBS_HOST_INTERFACE, 
                  CS4224_PRBS_Tx_2exp7, 
                  FALSE);

    /* Turn on the PRBS generator on slice 0 */
    status |= cs4224_diags_prbs_generator_enable(
                  0,  
                  CS4224_PRBS_HOST_INTERFACE, 
                  TRUE);

    /* configure the PRBS checker on slice 0 */
    status |= cs4224_diags_prbs_checker_config(
                  0,    
                  CS4224_PRBS_HOST_INTERFACE, 
                  CS4224_PRBS_Tx_2exp7, 
                  FALSE, 
                  FALSE);


    /* Turn on the PRBS checker on slice 0 */
    status |= cs4224_diags_prbs_checker_enable(
                  0,    
                  CS4224_PRBS_HOST_INTERFACE, 
                  TRUE);


    /* clear any initial PRBS errors */
    status |= cs4224_diags_prbs_checker_get_errors(
                  0,
                  CS4224_PRBS_HOST_INTERFACE,
                  &prbs_error_count);

    /* delay for a few seconds */

    /* get the PRBS error count */
    status |= cs4224_diags_prbs_checker_get_status(
                  0,
                  CS4224_PRBS_HOST_INTERFACE,
                  &prbs_error_count,
                  &prbs_sync);


    if (prbs_sync)
    {
        CS_PRINTF(("PRBS synchronized, error count %d\n", prbs_error_count));
    }
    else
    {
        CS_PRINTF(("PRBS not synchronized, error count %d\n", prbs_error_count));
    }
    return status;
}

