/** @file main.c
 *****************************************************************************
 *
 * @brief
 *    This module provides a examples of how to use the Leeds API. Refer
 *    to each example function for more detail.
 *
 *****************************************************************************
 * @author
 *    Copyright (c) 2011-2015, Inphi Corporation
 *    All rights reserved.
 *    
 *    Redistribution and use in source and binary forms, with or without modification, 
 *    are permitted provided that the following conditions are met:
 *    
 *    1.	Redistributions of source code must retain the above copyright notice, 
 *       this list of conditions and the following disclaimer.
 *    
 *    2.	Redistributions in binary form must reproduce the above copyright notice, 
 *       this list of conditions and the following disclaimer in the documentation and/or 
 *       other materials provided with the distribution.
 *    
 *    3.	Neither the name of Inphi Corporation nor the names of its contributors 
 *       may be used to endorse or promote products derived from this software without 
 *       specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 *    THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 *    PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *    CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 *    PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 *    OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 *    WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 *    OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 *    ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *    API Version Number: 3.7.8
 ****************************************************************************/
#include <stdlib.h>
#include <string.h>
#include "examples.h"

#if 0
void __cyg_profile_func_enter( void *, void * ) __attribute__ ((no_instrument_function));

void __cyg_profile_func_enter(void *func, void *callsite)
{
  printf("    enter %p\n", func);
  fflush(stdout);
}
void __cyg_profile_func_exit( void *, void * ) __attribute__ ((no_instrument_function));

void __cyg_profile_func_exit(void *func, void *callsite)
{
  printf("    exit %p\n", func);
  fflush(stdout);
}
#endif

typedef struct
{
    const char* name;
    const char* desc;
    cs_status (*func_ptr)();
}cs_example_t;


/* The full list of examples that can be run */
cs_example_t g_examples[] = {

    /* Diagnostics */
    {"version",              "Dump the driver version",     example_version_info},
    {"dump_registers",       "Dump the registers",          example_register_dump},
    {"dump_registers_range", "Dump a range of registers",   example_register_dump_range},
    {"sweep_registers",      "Sweep the registers",         example_register_sweep},
    {"prbs",                 "PRBS example",                example_prbs},
    {"loopbacks",            "Loopback example",            example_loopbacks},
    {"link_ready",           "Link ready example",          example_link_ready},
    {"wait_link_ready",      "Wait for link ready example", example_wait_link_ready},
    {"status",               "Status example",              example_status},

    /* Initialization Examples */
    {"init_10g",      "Initialize the device in 10G mode", example_init_10g},
    {"init_1g",       "Initialize the device in 1G mode",  example_init_1g},

 
    /* Interrupt Handling Examples */
    {"lock_interrupts",         "Receiver Lock Interrupt Example", example_interrupts_receive_lock_status},
    {"gpio_interrupts",         "GPIO Input Interrupts Example",   example_interrupts_gpio},
    {"mseq_ps_interrupts",      "MSEQ Program Store Interrupts Example", example_interrupts_mseq_ps}


};


/**
 * This method is called by the main() routine to
 * print a summary of the examples that can be run
 * against the evaluation board.
 *
 * @return Always CS_OK for now.
 */
cs_status cs_list_examples()
{
    int i;

    CS_PRINTF(("\nTest Summary\n"));
    CS_PRINTF(("============\n"));
    for(i = 0; i < sizeof(g_examples)/sizeof(cs_example_t); i++)
    {
        CS_PRINTF(("  %-25s = %-45s \n", g_examples[i].name, g_examples[i].desc));
    }
    
    return CS_OK;
}


/**
 * This method is called by the main() routine to
 * run one of the examples that are part of this package. It
 * runs the example against the evaluation board
 *
 * @param example [I] - The name associated with the example to run.
 *
 * @return CS_OK on success, CS_ERROR on failure.
 */
cs_status cs_run_example(const char* example)
{
    int i;

    for(i = 0; i < sizeof(g_examples)/sizeof(cs_example_t); i++)
    {
        if(0 == strcmp(example, g_examples[i].name))
        {
            return g_examples[i].func_ptr();
        }
    }

    CS_PRINTF(("Test %s not found\n", example));

    return CS_ERROR;
}

/**
 * This is the main example method for the $SKU API.
 *
 * This example makes use of the GUI for the evaluation board
 * to talk to the device. To do this it makes use of the following
 * method which opens a connection to the GUI to talk to the device:
 *
 *     cs_dbg_set_remote_server()
 *
 * To connect to the GUI the following command must first be
 * run from the scripts tab:
 *     server_open(60000)
 * where 60000 is the port number that the GUI will listen on
 * for remote connections.
 *
 * @return EXIT_SUCCESS on success, EXIT_FAILURE on failure.
 */
int main(int argc, char* argv[])
{
    if(argc < 4)
    {
        CS_PRINTF(("This example program attempts to communicate\n"
               "with the evaluation board GUI. To use it you\n"
               "need to specify the IP address and port number\n"
               "of the eval GUI or modify the example for your\n"
               "environment\n"
               "Usage: %s ip_addr port_num test_name\n", argv[0]));

        cs_list_examples();
        return EXIT_FAILURE; 
    }

    CS_PRINTF(("Connecting to %s:%s\n", argv[1], argv[2]));
    if(CS_OK != cs_dbg_set_remote_server(argv[1], strtoul(argv[2], NULL, 10)) )
    {
        return EXIT_FAILURE;
    }

    if(CS_OK != cs_run_example(argv[3]))
    {
        return EXIT_FAILURE;
    }

    return EXIT_SUCCESS;
}

