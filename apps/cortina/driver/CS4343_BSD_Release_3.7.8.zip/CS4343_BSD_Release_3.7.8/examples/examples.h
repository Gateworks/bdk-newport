/** @file examples.h
 *****************************************************************************
 *
 * @brief
 *    This module provides examples of using the CS4224 API to interact
 *    with the device.
 *
 *****************************************************************************
 * @author
 *    Copyright (c) 2011-2015, Inphi Corporation
 *    All rights reserved.
 *    
 *    Redistribution and use in source and binary forms, with or without modification, 
 *    are permitted provided that the following conditions are met:
 *    
 *    1.	Redistributions of source code must retain the above copyright notice, 
 *       this list of conditions and the following disclaimer.
 *    
 *    2.	Redistributions in binary form must reproduce the above copyright notice, 
 *       this list of conditions and the following disclaimer in the documentation and/or 
 *       other materials provided with the distribution.
 *    
 *    3.	Neither the name of Inphi Corporation nor the names of its contributors 
 *       may be used to endorse or promote products derived from this software without 
 *       specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 *    THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 *    PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *    CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 *    PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 *    OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 *    WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 *    OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 *    ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *    API Version Number: 3.7.8
 ****************************************************************************/
#include "cs4224_api.h"

/* Connect to the eval board to run the examples */
cs_status cs_dbg_set_remote_server(const char* ip, int port);

/*=======================================
 * Device initialization examples
 *=====================================*/
cs_status example_init_10g();
cs_status example_init_1g();
cs_status example_init_fracdiv_10p3125g();
cs_status example_init_fc8g();
cs_status example_init_fcan();
cs_status example_init_fracdiv_11p5g();
cs_status example_init_kran();
cs_status example_init_kran_tpm();
cs_status example_init_switch_dyn_rate();
cs_status example_init_2x2_switch();
cs_status example_init_dynamic_reinit();
cs_status example_init_eeprom();

/*=======================================
 * Diagnostic Methods
 *=====================================*/
cs_status example_register_dump();
cs_status example_register_dump_range();
cs_status example_register_sweep();
cs_status example_loopbacks();
cs_status example_prbs();
cs_status example_version_info();
cs_status example_link_ready();
cs_status example_wait_link_ready();
cs_status example_status();
cs_status example_eye_monitor();
cs_status example_eye_size();



/*=======================================
 * Examples of managing interrupts
 *=====================================*/
cs_status example_interrupts_receive_lock_status(void);
cs_status example_interrupts_gpio(void);
cs_status example_interrupts_mseq_ps(void);

