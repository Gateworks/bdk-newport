/** @file debug.c
 ****************************************************************************
 *
 * @brief
 *    This module contains debug implementations of the cs4224_reg_get(),
 *    cs4224_reg_set() methods.
 *
 ******************************************************************************
 * @author
 *    Copyright (c) 2011-2015, Inphi Corporation
 *    All rights reserved.
 *    
 *    Redistribution and use in source and binary forms, with or without modification, 
 *    are permitted provided that the following conditions are met:
 *    
 *    1.	Redistributions of source code must retain the above copyright notice, 
 *       this list of conditions and the following disclaimer.
 *    
 *    2.	Redistributions in binary form must reproduce the above copyright notice, 
 *       this list of conditions and the following disclaimer in the documentation and/or 
 *       other materials provided with the distribution.
 *    
 *    3.	Neither the name of Inphi Corporation nor the names of its contributors 
 *       may be used to endorse or promote products derived from this software without 
 *       specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 *    THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 *    PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *    CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 *    PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 *    OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 *    WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 *    OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 *    ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *    API Version Number: 3.7.8
 ******************************************************************************/
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <time.h>

#include "cs4224_api.h"
#include "client.h"

#ifndef _WINDOWS
#    include <sys/types.h>
#    include <sys/socket.h>
#    include <unistd.h>
#    include <netinet/in.h>
#    include <netdb.h>
#    include <memory.h>
#    include <arpa/inet.h>
#    include <errno.h>
#endif

/* ANSI C doesn't declare these methods */
#ifndef __APPLE__
int snprintf(char *str, size_t size, const char *format, ...);
#endif /* __APPLE__ */
int gethostname(char* name, size_t len);


/* Determine whether register accesses should be performed locally or via
 * a remote host such as the DV environment */
cs_uint8  g_use_remote_server  = 0;
char*  g_remote_server_ip   = NULL;
char   g_remote_server_ip_buf[256];
cs_uint16 g_remote_server_port = 0;
client_t g_remote_connection;

/**
 * This is a debugging routine used to connect to the h/w remotely such
 * as via the GUI shipped with the evaluation board. In order to connect
 * to the GUI it is necessary to execute the server_open() method in
 * the scripts tab. For example:
 *
 *    server_open(60000)
 *
 * @private
 */
cs_status cs_dbg_set_remote_server(const char* ip, int port)
{
    client_t* client;
    char request[512];
    cs_boolean locked = FALSE;
    char hostname[256];
    int random_id = 0;

    /* Initialize the random seed */
    srand(time(NULL));
    
    /* Retrieve our hostname */
    gethostname(hostname, 256);

    g_remote_server_ip = &g_remote_server_ip_buf[0];
    strcpy(g_remote_server_ip, ip);

    g_remote_server_port = port;
    g_use_remote_server = 1;

    client = &g_remote_connection;
    client_init(client);

    /* printf("Connecting to %s:%d\n", g_remote_server_ip, g_remote_server_port); */
    if(CS_OK != client_open(client, g_remote_server_ip, g_remote_server_port))
    {
        return CS_ERROR;
    }

    /* Now lock the interface */
    random_id = rand();
    snprintf((char*)request, 500, "lock,%s_%d,0,0\n", (char*)hostname, random_id);
    while(!locked)
    {
        char response[256];
        client_send(client, request, strlen(request));
        client_recv(client, response, 255);

        if(NULL != strstr(response, "false"))
        {
            locked = FALSE;
            printf("Server interface locked, waiting 5s\n");
            CS_MDELAY(5000);
        }
        else
        {
            locked = TRUE;
            CS_MDELAY(2000);
            break;
        }
    }

    return CS_OK;
}


cs_uint16 g_registers[2][0x6000];


/**
 * This method is called to read a register on the LEEDS device.
 *
 * @param die    [I] - The die of the device to access
 * @param addr   [I] - The address of the register to access
 * @param data   [O] - The data read from the register
 *
 * @return CS_OK on success, CS_ERROR on failure
 */
cs_status cs4224_reg_get(cs_uint32 die, cs_uint32 addr, cs_uint16* data)
{
    char buffer[512];
    int count = 0;
    int max_bytes = 255;
    
    if (addr >= 0x6000)
    {
        /* printf("Address out of range = %x\n", addr); */
        return CS_ERROR;
    }

    if(!g_use_remote_server)
    {
        *data = g_registers[die][addr];
        return CS_OK;
    }
    
    snprintf(buffer, 500, "r2,%x,0,%d\n", addr, die);
    /*printf("Sending buffer [%s]\n", buffer);*/
    count = client_send(&g_remote_connection, buffer, strlen(buffer)+1);
    if(count == 0)
    {
        return CS_ERROR;
    }

    count = client_recv(&g_remote_connection, buffer, max_bytes);
    if(count == 0)
    {
        return CS_ERROR;
    }
    /* printf("buffer = %s\n", buffer); */

    if(buffer != NULL)
    {
        *data = strtoul(buffer, 0, 16) & 0xFFFF;
    }
    
    return CS_OK;
}

/**
 * This method is called to set a register on the LEEDS device.
 *
 * @param die    [I] - The die of the device to access
 * @param addr   [I] - The address of the register to access
 * @param data   [I] - The data to write to the register
 *
 * @return CS_OK on success, CS_ERROR on failure
 */
cs_status cs4224_reg_set(cs_uint32 die, cs_uint32 addr, cs_uint16 data)
{
    char buffer[512];
    int count = 0;
    int max_bytes = 255;

    if (addr >= 0x6000)
    {
        /* printf("Address out of range = %x\n", addr); */
        return CS_ERROR;
    }

    if(!g_use_remote_server)
    {
        g_registers[die][addr] = data;
        return CS_OK;
    }
   
    snprintf(buffer, 500, "w2,%x,%x,%d,0\n", addr, data, die);
    /* printf("Sending buffer [%s]\n", buffer); */
    count = client_send(&g_remote_connection, buffer, strlen(buffer)+1);
    if(count == 0)
    {
        return CS_ERROR;
    }

    count = client_recv(&g_remote_connection, buffer, max_bytes);
    if(count == 0)
    {
        return CS_ERROR;
    }
    
    return CS_OK;
}


