/** @file client.c
 *****************************************************************************
 *
 * @brief
 *    This module contains a primitive socket client used to communicate
 *    with the GUI for the evaluation board for testing.
 *
 *****************************************************************************
 * @author
 *    Copyright (c) 2011-2015, Inphi Corporation
 *    All rights reserved.
 *    
 *    Redistribution and use in source and binary forms, with or without modification, 
 *    are permitted provided that the following conditions are met:
 *    
 *    1.	Redistributions of source code must retain the above copyright notice, 
 *       this list of conditions and the following disclaimer.
 *    
 *    2.	Redistributions in binary form must reproduce the above copyright notice, 
 *       this list of conditions and the following disclaimer in the documentation and/or 
 *       other materials provided with the distribution.
 *    
 *    3.	Neither the name of Inphi Corporation nor the names of its contributors 
 *       may be used to endorse or promote products derived from this software without 
 *       specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 *    THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 *    PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *    CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 *    PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 *    OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 *    WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 *    OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 *    ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *    API Version Number: 3.7.8
 *****************************************************************************/
#include "client.h"
#include <stdio.h>

#ifndef _WINDOWS
#    include <sys/types.h>
#    include <sys/socket.h>
#    include <unistd.h>
#    include <netinet/in.h>
#    include <netdb.h>
#    include <memory.h>
#    include <arpa/inet.h>
#    include <errno.h>
#endif


/**
 * This method is used to create a client object that is used to communicate
 * with a remote server such as the eval board GUI.
 *
 * @private
 */
int client_init(client_t* slice)
{
    slice->port = 0;
    slice->ip[0] = 0;
    slice->socket = 0;

    return CS_OK;
}


/**
 * This is the open method used to establish a connection with a remote
 * server such as the eval board GUI.
 *
 * @private
 */
int client_open(client_t* slice, char* ip, cs_uint16 port)
{
    struct sockaddr_in addr;
    /*struct hostent* server;*/
    int rc;

    slice->port = port;
    strcpy(slice->ip, ip);

    slice->socket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

    if(slice->socket < 0)
    {
        printf("failed to create socket to connect to server\n");
        return CS_ERROR;
    }

    /*server = gethostbyname(ip);*/

    memset(&addr, 0, sizeof(addr));
    /*printf("server->h_addr = %s\n", (char*)(server->h_addr));*/

    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = inet_addr(ip);
    addr.sin_port = htons(port);

    /* Establish the connection */
    errno = 0;
    /*printf("socket = %d, ip = %s, port = %d\n", slice->socket, ip, port);*/
    rc = connect(slice->socket, (struct sockaddr*)&addr, sizeof(addr));

    if(rc < 0)
    {
        close(slice->socket);
        printf("Failed to connect to server, rc = %d, errno = %d\n", rc, errno);
        return CS_ERROR;
    }

    return CS_OK;
}


/**
 * Send a message to a remote server to perform register read/write operations
 *
 * @private
 */
int client_send(client_t* slice, char* buffer, int length)
{
	int total_bytes = 0;
	
	while(total_bytes < length)
	{
		int bytes_sent = send(slice->socket, (const char*)(buffer + total_bytes), length, 0);

		if(bytes_sent == -1)
		{
			printf("Failed sending data to the server\n");
            return CS_ERROR;
		}

		total_bytes += bytes_sent;
	}

    return total_bytes;
}


/** 
 * Receive a message from the remote server to perform register read/write operations
 *
 * @private
 */
int client_recv(client_t* slice, char* buffer, int max_bytes)
{
	int bytes_recv = 0;

	bytes_recv = recv(slice->socket, (char*)buffer, max_bytes, 0);

	if(bytes_recv == -1)
	{
		printf("Failed receiving data from the server\n");
		bytes_recv = 0;
	}

	buffer[bytes_recv] = 0;

    if(bytes_recv == -1)
    {
        return CS_ERROR;
    }

    return bytes_recv;
}


/**
 * Close the connection to the remote server.
 *
 * @private
 */
int client_close(client_t* slice)
{
#ifndef _WINDOWS
    shutdown(slice->socket, SHUT_RDWR);
#endif
    close(slice->socket);

    return CS_OK;
}

