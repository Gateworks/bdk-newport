/** @file example_lock_detect_interrupts.c
 *****************************************************************************
 *
 * @brief
 *    This module provides examples of configuring and handling device
 *    interrupts for the CS4224 family of devices.
 *
 *****************************************************************************
 * @author
 *    Copyright (c) 2011-2015, Inphi Corporation
 *    All rights reserved.
 *    
 *    Redistribution and use in source and binary forms, with or without modification, 
 *    are permitted provided that the following conditions are met:
 *    
 *    1.	Redistributions of source code must retain the above copyright notice, 
 *       this list of conditions and the following disclaimer.
 *    
 *    2.	Redistributions in binary form must reproduce the above copyright notice, 
 *       this list of conditions and the following disclaimer in the documentation and/or 
 *       other materials provided with the distribution.
 *    
 *    3.	Neither the name of Inphi Corporation nor the names of its contributors 
 *       may be used to endorse or promote products derived from this software without 
 *       specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 *    THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 *    PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *    CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 *    PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 *    OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 *    WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 *    OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 *    ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *    API Version Number: 3.7.8
 ****************************************************************************/
#include "cs4224_api.h"

/* This is an example of an interrupt handler for managing
 * the RXLOCKD0_INTERRUPT interrupt. In this example we've
 * masked out everything except the filt_locki interrupt bit.
 * which is a debounced version of the lock detector status.
 *
 * The interrupt source would have already been
 * cleared by the time this method is called.
 *
 * Keep in mind that this method would probably be called from
 * ISR context. You may only want to do light weight processing
 * in this method and schedule any major processing for a
 * background task.
 */
void handle_rx_lock(cs4224_irq_handler_data_t data)
{
    cs_uint16 reg_data;
    cs_uint32 slice = data.handle;
    cs_uint32 lock_status_addr = 0;
    const char* lock_label = NULL;
   
    if(data.node->ireg == CS4224_PP_LINE_SDS_COMMON_RXLOCKD0_INTERRUPT)
    {
        lock_status_addr = CS4224_PP_LINE_SDS_COMMON_RXLOCKD0_INTSTATUS;
        lock_label = "Line Receive";
    }
    else
    {
        lock_status_addr = CS4224_PP_HOST_SDS_COMMON_RXLOCKD0_INTSTATUS;
        lock_label = "Host Receive";
    }
    
    CS_PRINTF(("Handling Lock detect status interrupt, slice = %d\n", slice));

    /* Need to query the status since it isn't properly
     * set in the sreg_data field */
    cs4224_reg_get_channel(slice, lock_status_addr, &reg_data);

    /* If the filt_locki bit is set then the lock detector status has changed */
    if(0x0040 == (reg_data & 0x0040))
    {
        CS_PRINTF(("  %s on slice %d locked\n", lock_label, slice));
    }
    else
    {
        CS_PRINTF(("  %s on slice %d not locked\n", lock_label, slice));
    }
}



/**
 * This method is a demonstration of using the RXLOCKD0_INTERRUPT
 * registers on the host and line interfaces.
 *
 * @param slice [I] - The slice to enable the interrupt on.
 *
 * @return CS_OK on success, CS_ERROR on failure.
 */
cs_status cs4224_receive_lock_interrupt(cs_uint32 slice)
{
    cs_status status = CS_OK;
    cs4224_gpio_cfg_t gpio_cfg;
    cs4224_irq_node_t* interrupt_node;
    cs_uint16 interrupt_reg_addr;
    cs_uint16 interrupt_reg_trigger_addr;
     
    CS_PRINTF(("Running the receive lock interrupt example\n"));
   
    /* Configure the interrupt pin if it isn't already configured. Internally
     * the interrupt pin is mapped to CS4224_GPIOINTERR. It is shared between
     * all slices */
    cs4224_gpio_cfg_output(&gpio_cfg, CS4224_GPIO_OUT_FCN_COMMON_GLOBAL_INT);
    gpio_cfg.pullup_10k = 1;    /* Open drain requires pullup */
    gpio_cfg.invert_output = 1; /* Open drain interrupt should be active low */
    status |= cs4224_gpio_init(slice, CS4224_GPIOINTERR, &gpio_cfg);


    /* If this is a simplex device then we need to determine whether
     * the receive interrupt is ingress or egress */
    if(cs4224_is_hw_simplex(slice))
    {
        if(cs4224_line_rx_to_host_tx_dir(slice))
        {
            interrupt_node = &CS4224_IRQ_NODE_PP_LINE_SDS_COMMON_RXLOCKD0_INTERRUPT;
            interrupt_reg_addr = CS4224_PP_LINE_SDS_COMMON_RXLOCKD0_INTERRUPT;
            interrupt_reg_trigger_addr = CS4224_PP_LINE_SDS_COMMON_RXLOCKD0_INTERRUPTZ;
        }
        else
        {
            interrupt_node = &CS4224_IRQ_NODE_PP_HOST_SDS_COMMON_RXLOCKD0_INTERRUPT;
            interrupt_reg_addr = CS4224_PP_HOST_SDS_COMMON_RXLOCKD0_INTERRUPT;
            interrupt_reg_trigger_addr = CS4224_PP_HOST_SDS_COMMON_RXLOCKD0_INTERRUPTZ;
        }
    }
    else
    {
        interrupt_node = &CS4224_IRQ_NODE_PP_LINE_SDS_COMMON_RXLOCKD0_INTERRUPT;
        interrupt_reg_addr = CS4224_PP_LINE_SDS_COMMON_RXLOCKD0_INTERRUPT;
        interrupt_reg_trigger_addr = CS4224_PP_LINE_SDS_COMMON_RXLOCKD0_INTERRUPTZ;
    }
    
    /* First clear out any latched interrupts so they don't
     * affect our test */
    status |= cs4224_reg_set_channel(slice, interrupt_reg_addr, 0xffff);
        
    cs4224_irq_enable(slice,
                      interrupt_node,
                      /* Just enable the filt_locki change bit */
                      0x40,
                      CS4224_IRQ_DIR_UP);

    /* Register an interrupt handler to handle the line RX lock detector */
    if(!cs4224_irq_register_handler_exists(interrupt_node))
    { 
        CS_PRINTF(("  Registering interrupt handler for lock detect interrupt\n"));
        status |= cs4224_irq_register_handler(
            interrupt_node,
            handle_rx_lock);
    }

    /* For debugging purposes we'll print the enabled interrupts to
     * ensure that it is present */
    CS_PRINTF(("  Printing enabled interrupts\n"));
    status |= cs4224_irq_print_enabled_interrupts(slice);

    /* To simplify testing we'll fake out an interrupt by
     * firing one of the interrupt trigger registers. This
     * is possible with most of the interrupts. */
    status |= cs4224_reg_set_channel(slice, interrupt_reg_trigger_addr, 0x40);

    /* Call the ISR to handle any active interrupts. Normally
     * this would be called when the interrupt pin from the
     * ASIC is asserted.
     *
     * This will automatically call any interrupt handlers
     * that were registered for enabled interrupts */
    CS_PRINTF(("  Calling interrupt handler\n"));
    status |= cs4224_irq_isr(slice);

    /* Calling again the interrupt won't be set anymore */
    CS_PRINTF(("  Calling interrupt handler again, this time nothing is set\n"));
    status |= cs4224_irq_isr(slice);

    /* Now fake out another interrupt. The lock detect status
     * won't change because we haven't actually changed the
     * underlying status register. We're just faking out an
     * interrupt.
     */
    CS_PRINTF(("  Force another link change interrupt\n"));
    status |= cs4224_reg_set_channel(slice, interrupt_reg_trigger_addr, 0x40);
    status |= cs4224_irq_isr(slice);

    return status;
}


/**
 * This method is a top level test method used to call the interrupt
 * handler on multiple slices of the device.
 *
 * @return CS_OK on success, CS_ERROR on failure.
 */
cs_status example_interrupts_receive_lock_status(void)
{
    cs_status status = CS_OK;

    status |= cs4224_receive_lock_interrupt(14);

    return status;
}
