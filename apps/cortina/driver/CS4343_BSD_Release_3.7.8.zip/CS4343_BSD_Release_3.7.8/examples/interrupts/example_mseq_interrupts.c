/** @file example_mseq_interrupts.c
 *****************************************************************************
 *
 * @brief
 *    This module provides examples of configuring and handling device
 *    interrupts for the CS4224 family of devices.
 *
 *****************************************************************************
 * @author
 *    Copyright (c) 2011-2015, Inphi Corporation
 *    All rights reserved.
 *    
 *    Redistribution and use in source and binary forms, with or without modification, 
 *    are permitted provided that the following conditions are met:
 *    
 *    1.	Redistributions of source code must retain the above copyright notice, 
 *       this list of conditions and the following disclaimer.
 *    
 *    2.	Redistributions in binary form must reproduce the above copyright notice, 
 *       this list of conditions and the following disclaimer in the documentation and/or 
 *       other materials provided with the distribution.
 *    
 *    3.	Neither the name of Inphi Corporation nor the names of its contributors 
 *       may be used to endorse or promote products derived from this software without 
 *       specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 *    THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 *    PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *    CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 *    PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 *    OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 *    WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 *    OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 *    ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *    API Version Number: 3.7.8
 ****************************************************************************/
#include "cs4224_api.h"


/* This is an example of an interrupt handler for managing
 * the MSEQ_PS_INT
 */
void handle_mseq_ps_int(cs4224_irq_handler_data_t data)
{
    CS_PRINTF(("Handling MSEQ_PS_INT interrupt, slice = %d\n", data.handle));
}


/**
 * This method is a demonstration of using the MSEQ_PS_INT
 * interrupt register.
 *
 * @param slice [I] - The slice to enable the interrupt on.
 *
 * @return CS_OK on success, CS_ERROR on failure.
 */
cs_status cs4224_mseq_ps_interrupt(cs_uint32 slice)
{
    cs_status status = CS_OK;
    cs4224_gpio_cfg_t gpio_cfg;
     
    CS_PRINTF(("Running the MSEQ_PS_INT interrupt example\n"));
   
    /* Configure the interrupt pin if it isn't already configured. Internally
     * the interrupt pin is mapped to CS4224_GPIOINTERR. It is shared between
     * all slices */
    cs4224_gpio_cfg_output(&gpio_cfg, CS4224_GPIO_OUT_FCN_COMMON_GLOBAL_INT);
    gpio_cfg.pullup_10k = 1;    /* Open drain requires pullup */
    gpio_cfg.invert_output = 1; /* Open drain interrupt should be active low */
    status |= cs4224_gpio_init(slice, CS4224_GPIOINTERR, &gpio_cfg);

    /* First clear out any latched interrupts so they don't
     * affect our test */
    status |= cs4224_reg_set_channel(slice, CS4224_MSEQ_PS_INT, 0xffff);
    status |= cs4224_reg_set_channel(slice, CS4224_MSEQ_PS_INT, 0xffff);

    /* Enable the filt_locki bit of the line receive lock detect interrupt */
    status |= cs4224_irq_enable(slice,
                     &CS4224_IRQ_NODE_MSEQ_PS_INT,
                     /* Enable both the ECC bits */
                     0xffff,
                     CS4224_IRQ_DIR_UP);

    /* Register an interrupt handler to handle the line RX lock detector */
    if(!cs4224_irq_register_handler_exists(&CS4224_IRQ_NODE_MSEQ_PS_INT))
    { 
        CS_PRINTF(("  Registering interrupt handler for MSEQ_PS_INT\n"));
        status |= cs4224_irq_register_handler(
            &CS4224_IRQ_NODE_MSEQ_PS_INT,
            handle_mseq_ps_int);
    }

    /* For debugging purposes we'll print the enabled interrupts to
     * ensure that it is present */
    CS_PRINTF(("  Printing enabled interrupts\n"));
    status |= cs4224_irq_print_enabled_interrupts(slice);

    /* To simplify testing we'll fake out an interrupt by
     * firing one of the interrupt trigger registers. This
     * is possible with most of the interrupts. */
    status |= cs4224_reg_set_channel(slice, CS4224_MSEQ_PS_INTZ, 0x2);

    /* Call the ISR to handle any active interrupts. Normally
     * this would be called when the interrupt pin from the
     * ASIC is asserted.
     *
     * This will automatically call any interrupt handlers
     * that were registered for enabled interrupts */
    CS_PRINTF(("  Calling interrupt handler\n"));
    status |= cs4224_irq_isr(slice);

    /* Calling again the interrupt won't be set anymore */
    CS_PRINTF(("  Calling interrupt handler again, this time nothing is set\n"));
    status |= cs4224_irq_isr(slice);

    /* Now fake out another interrupt. */
    CS_PRINTF(("  Force another MSEQ_PS_INT input change interrupt\n"));
    status |= cs4224_reg_set_channel(slice, CS4224_MSEQ_PS_INTZ, 0x2);
    
    /* Make sure there is no interrupt on slice 0 */
    CS_PRINTF(("  Ensuring MSEQ_PS_INT interrupt is also fired on slice 0\n"));
    status |= cs4224_irq_isr(0);

    CS_PRINTF(("  Ensuring MSEQ_PS_INT interrupt is now cleared on slice %d\n", slice));
    status |= cs4224_irq_isr(slice);


    return status;
}


/**
 * This method is a top level test method used to call the interrupt
 * handler on multiple slices of the device.
 *
 * @return CS_OK on success, CS_ERROR on failure.
 */
cs_status example_interrupts_mseq_ps(void)
{
    cs_status status = CS_OK;
    
    status |= cs4224_mseq_ps_interrupt(0);

    return status;
}

