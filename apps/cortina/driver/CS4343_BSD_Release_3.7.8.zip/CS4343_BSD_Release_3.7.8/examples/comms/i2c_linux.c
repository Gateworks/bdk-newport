/** @file i2c_linux.c
 *****************************************************************************
 *
 * @brief
 * Provides a simple user-land linux I2C driver for accessing registers
 * 
 * For making a kernel driver, a lot of the setup is the same however the functions 
 * and structs are slightly different. See the docs here:
 * https://www.kernel.org/doc/htmldocs/device-drivers/i2c.html
 * 
 * NOTE: This has been tested on the IT OMAP based BeagleBone Black.
 * 
 *****************************************************************************
 * @author
 *    Copyright (c) 2011-2015, Inphi Corporation
 *    All rights reserved.
 *    
 *    Redistribution and use in source and binary forms, with or without modification, 
 *    are permitted provided that the following conditions are met:
 *    
 *    1.	Redistributions of source code must retain the above copyright notice, 
 *       this list of conditions and the following disclaimer.
 *    
 *    2.	Redistributions in binary form must reproduce the above copyright notice, 
 *       this list of conditions and the following disclaimer in the documentation and/or 
 *       other materials provided with the distribution.
 *    
 *    3.	Neither the name of Inphi Corporation nor the names of its contributors 
 *       may be used to endorse or promote products derived from this software without 
 *       specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 *    THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 *    PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *    CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 *    PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 *    OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 *    WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 *    OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 *    ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *    API Version Number: 3.7.8
 ****************************************************************************/

/* for ioctl() */
#include <sys/ioctl.h>
/* for i2c defines */
#include <linux/i2c.h>
/* for i2c structs and functions */
#include <linux/i2c-dev.h>
/* for open() */
#include <fcntl.h>
/* for close() */
#include <unistd.h>
/* for strto* */
#include <stdlib.h>
/*for errno*/
#include <errno.h>
/*for strerror*/
#include <string.h>

/* for cs types */
#include <cs_types.h>
/* for CS_TRACE */
#include <cs_rtos.h>


/**
 * Read register over I2C.
 * 
 * Meant for user-land linux applications.
 * 
 * Arguments follow naming convention used in the I2C section of the datasheet
 * 
 * @param i2c_file      [I] - Opened I2C /dev file
 * @param slave_address [I] - Un-shifted slave address of the CS4224 device
 * @param register_addr [I] - Register to read on the device
 * @param read_data     [O] - Register data read from the device
 * 
 * @return CS_OK on success, CS_ERROR otherwise
 * 
 * 
 */
cs_status cs_i2c_read(cs_int32 i2c_file, cs_uint8 slave_address, cs_uint16 register_addr, cs_uint16 *read_data)
{
    cs_uint16 cksum = 0;
    cs_uint8  reg_addr_high = 0;
    cs_uint8  reg_addr_low = 0;
    cs_uint8  outbuf[3] = {0, 0, 0};
    cs_uint8  inbuf[3]  = {0, 0, 0};
    int       ret = 0;
    /* from linux/i2c-dev.h */
    struct i2c_rdwr_ioctl_data i2c_data;
    /* from linux/i2c.h */
    struct i2c_msg msgs[2];
    
    *read_data = 0xbada;
    
    /* slave address will be shifted by one and then the read/write bit set by the i2c-dev functions */
    
    /* register address needs a 'read combined format' bit set */
    reg_addr_high = ((register_addr & 0xFF00) >> 7) | 0x1; /* read c.f. */
    reg_addr_low =  (register_addr & 0xFF);
    
    /* checksum is the regsiter address data one-compliment added and then inverted */
    cksum = reg_addr_high + reg_addr_low;
    cksum = (cksum >> 8) + (cksum & 0xFF); /* handle carry bit by adding the two halves of cksum */
    cksum = 0x00FF & (~cksum);
    
    /* construct the first message, which is the write to tell the device which 16bit register to read */
    msgs[0].addr  = slave_address;
    msgs[0].flags = 0; /* write */
    msgs[0].len   = sizeof(outbuf)/sizeof(outbuf[0]);
    msgs[0].buf   = outbuf;
    
    /* The first byte indicates which register we'll write */
    outbuf[0] = reg_addr_high;
    outbuf[1] = reg_addr_low;
    outbuf[2] = cksum;
    
    /* the second message is the actual read, after the i2c restart event */
    msgs[1].addr  = slave_address;
    msgs[1].flags = I2C_M_RD; /* read */
    msgs[1].len   = sizeof(inbuf)/sizeof(inbuf[0]);
    msgs[1].buf   = inbuf;
    
    /* i2c_data is just a container for the messages */
    i2c_data.msgs  = msgs;
    i2c_data.nmsgs = sizeof(msgs)/sizeof(msgs[0]);
    
    /* send the data to the i2c-dev interface */
    ret = ioctl(i2c_file, I2C_RDWR, &i2c_data);
    if(ret < 0) {
        /* sometimes this can fail, for instance right after you hit the soft reset */
#ifdef DEBUG
        CS_TRACE(("ERROR: cannot send i2c read command, returned: %d  errorno: (%d) %s\n",ret,errno,strerror(errno)));
        CS_PRINTF(("  i2c_file: 0x%x slave_address: 0x%x register_addr: 0x%x i2c data out: 0x%x 0x%x 0x%x\n", \
            i2c_file, slave_address, register_addr, outbuf[0], outbuf[1], outbuf[2] ));
#endif
        return CS_ERROR;
    }
    
    /* calculate what the checksum should be */
    cksum = inbuf[0] + inbuf[1];
    cksum = (cksum >> 8) + (cksum & 0xFF); /* handle carry bit by adding the two halves of cksum */
    cksum = 0x00FF & (~cksum);
    
    if(cksum != inbuf[2]) {
        /* this should never happen unless you have a comms issue */
        CS_TRACE(("ERROR: read checksum does not equal calc checksum\n"));
        CS_PRINTF(("  i2c_file: 0x%x slave_address: 0x%x register_addr: 0x%x i2c data out: 0x%x 0x%x 0x%x\n", \
            i2c_file, slave_address, register_addr, outbuf[0], outbuf[1], outbuf[2] ));
        CS_PRINTF(("  read cksum: 0x%x calc cksum: 0x%x\n",inbuf[2],cksum));
        CS_PRINTF(("  read data: 0x%02x 0x%02x\n", inbuf[0], inbuf[1]));
        return CS_ERROR;
    }
    
    *read_data = (inbuf[0] << 8) | (inbuf[1] & 0xFF);
    
    return CS_OK;
}

/**
 * Write register over I2C.
 * 
 * Meant for user-land linux applications.
 * 
 * Arguments follow naming convention used in the I2C section of the datasheet
 * 
 * @param i2c_file      [I] - Opened I2C /dev file
 * @param slave_address [I] - Un-shifted slave address of the CS4224 device
 * @param register_addr [I] - Register to write on the device
 * @param write_data     [O] - Register data to write to the device
 * 
 * @return CS_OK on success, CS_ERROR otherwise
 * 
 * 
 */
cs_status cs_i2c_write(cs_int32 i2c_file, cs_uint8 slave_address, cs_uint16 register_addr, cs_uint16 write_data)
{
    cs_uint16 cksum = 0;
    cs_uint8  reg_addr_high = 0;
    cs_uint8  reg_addr_low = 0;
    cs_uint8  write_data_high = 0;
    cs_uint8  write_data_low = 0;
    cs_uint8  outbuf[5] = {0, 0, 0, 0, 0};
    cs_uint8  inbuf[1]  = {0};
    int       ret = 0;
    /* from linux/i2c-dev.h */
    struct i2c_rdwr_ioctl_data i2c_data;
    /* from linux/i2c.h */
    struct i2c_msg msgs[2];
    
    /* slave address will be shifted by one and then the read/write bit set by the i2c-dev functions */

    /* register address needs a 'write combined format' bit cleared */
    reg_addr_high = ((register_addr & 0xFF00) >> 7) | 0x0; /* write c.f. */
    reg_addr_low =  (register_addr & 0xFF);
    
    /* write data is easy, just split into bytes */
    write_data_high = (write_data>>8);
    write_data_low =  (write_data&0xFF);
    
    /* checksum is all the data one-compliment-added and then inverted */
    cksum = reg_addr_high + reg_addr_low + write_data_high + write_data_low;
    cksum = (cksum >> 8) + (cksum & 0xFF); /* handle carry bit by adding the two halves of cksum */
    cksum = (cksum >> 8) + (cksum & 0xFF); /* do it again in case there is more carrys */
    cksum = 0x00FF & (~cksum);
    
    /* construct the first message, which is the 16b addr, 16b data, and checksum */
    msgs[0].addr  = slave_address;
    msgs[0].flags = 0; /* write */
    msgs[0].len   = sizeof(outbuf)/sizeof(outbuf[0]);
    msgs[0].buf   = outbuf;
    
    outbuf[0] = reg_addr_high;
    outbuf[1] = reg_addr_low;
    outbuf[2] = write_data_high;
    outbuf[3] = write_data_low;
    outbuf[4] = cksum;
    
    /* the second message is to read the checksum, after the i2c restart event */
    msgs[1].addr  = slave_address;
    msgs[1].flags = I2C_M_RD; /* read */
    msgs[1].len   = sizeof(inbuf)/sizeof(inbuf[0]);
    msgs[1].buf   = inbuf;
    
    /* i2c_data is just a container for the messages */
    i2c_data.msgs  = msgs;
    i2c_data.nmsgs = sizeof(msgs)/sizeof(msgs[0]);
    
    /* send the data to the i2c-dev interface */
    ret = ioctl(i2c_file, I2C_RDWR, &i2c_data);
    if(ret < 0) {
        /* sometimes this can fail, for instance right after you hit the soft reset */
#ifdef DEBUG
        CS_TRACE(("ERROR: cannot send i2c write command, returned: %d  errno: (%d) %s\n",ret,errno,strerror(errno)));
        CS_PRINTF(("  i2c_file: 0x%x slave_address: 0x%x register_addr: 0x%x i2c data: 0x%x 0x%x 0x%x 0x%x 0x%x\n", \
                i2c_file, slave_address, register_addr, outbuf[0], outbuf[1], outbuf[2], outbuf[3], outbuf[4] ));
#endif
        return CS_ERROR;
    }
    
    /* checksum should return 0xFF */
    if(0xFF != inbuf[0]) {
        /* this should never happen unless you have a comms issue */
        CS_TRACE(("ERROR: read checksum does not equal calc checksum\n"));
        CS_PRINTF(("  i2c_file: 0x%x slave_address: 0x%x register_addr: 0x%x i2c data: 0x%x 0x%x 0x%x 0x%x 0x%x\n", \
                i2c_file, slave_address, register_addr, outbuf[0], outbuf[1], outbuf[2], outbuf[3], outbuf[4] ));
        CS_PRINTF(("  read cksum: 0x%x calc cksum: 0x%x\n",inbuf[0],0xFF));
        return CS_ERROR;
    }
    
    return CS_OK;
}


/**
 * Opens an I2C interface on /dev
 * 
 * To close, just use close(i2c_file)
 * 
 * @param dev_number [I] - i2c device under /dev/i2c-*
 * @param i2c_file   [O] - Resulting I2C file descriptor
 * 
 * @return CS_OK on success, CS_ERROR otherwise
 */
cs_status cs_i2c_open(cs_uint8 dev_number, cs_int32 *i2c_file)
{
    cs_status status = CS_OK;
    cs_char8 filename[20];
    
    if(snprintf(filename, 19, "/dev/i2c-%d", dev_number) < 0) {
        /* TODO: handle return code */
        return CS_ERROR;
    }
    
    *i2c_file = open(filename,O_RDWR);
    if(i2c_file < 0) {
        CS_TRACE(("ERROR: Cannot open %s. Return code: %d  errno: %s\n", filename, i2c_file, strerror(errno)));
        *i2c_file = 0;
        return CS_ERROR;
    }
    
    return status;
}


/* this define makes it easy to pull the i2c functions into another project */
#ifdef I2C_EXAMPLE

/* https://www.kernel.org/doc/Documentation/i2c/dev-interface
 * 
 * make sure to load the i2c-dev kernel module
 * $ sudo modprobe i2c-dev
 * On the beaglebone black (used for this example) we're using the i2c-1 interface which
 * is available on the headers (although the headers call it i2c-2!)
 */

int main(int argc, char **argv)
{
    cs_status status = CS_OK;
    cs_int32 i2c_file;
    
    if(cs_i2c_open(1, &i2c_file) != CS_OK) {
        CS_TRACE(("ERROR: Could not open i2c device #2\n"));
        return 1;
    }
    
    if( (argc >= 4) && (argv[1][0] == 'r') ) {
        /* read i2c reg:
         * r slave_addr reg_addr */
        cs_uint8  slave_address = strtoul(argv[2], NULL, 0);
        cs_uint16 register_addr = strtoul(argv[3], NULL, 0);
        cs_uint16 read_data = 0;
        /*CS_PRINTF(("slave: 0x%x  reg: 0x%x\n",slave_address, register_addr));*/
        
        status |= cs_i2c_read(i2c_file, slave_address, register_addr, &read_data);
        if(status != CS_OK) {
            CS_TRACE(("ERROR: Read failed\n"));
        }
        else {
            CS_PRINTF(("0x%04x = 0x%04x\n", register_addr, read_data));
        }
    }
    else if( (argc >= 5) && (argv[1][0] == 'w') ) {
        /* write i2c reg:
         * w slave_addr reg_addr value */
        cs_uint16 slave_address = strtoul(argv[2], NULL, 0);
        cs_uint16 register_addr = strtoul(argv[3], NULL, 0);
        cs_uint16 write_data    = strtoul(argv[4], NULL, 0);
        
        status |= cs_i2c_write(i2c_file, slave_address, register_addr, write_data);
        if(status != CS_OK) {
            CS_TRACE(("ERROR: Write failed\n"));
        }
        else {
            CS_PRINTF(("0x%04x set to 0x%04x\n", register_addr, write_data));
        }
    }
    else {
        CS_PRINTF(("ERROR: wrong arguments\n"));
        CS_PRINTF(("read : %s r slave_address register_addr\n", argv[0]));
        CS_PRINTF(("write: %s w slave_address register_addr write_data\n", argv[0]));
    }
    
    close(i2c_file);
    
    if(status != CS_OK) {
        return 1;
    }
    else {
        return 0;
    }
}

#endif



