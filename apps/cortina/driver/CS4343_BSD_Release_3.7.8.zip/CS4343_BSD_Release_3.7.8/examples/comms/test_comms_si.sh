#!/bin/bash
# @file test_comms_si.sh

set -o pipefail -o errexit

for i in {0..1000}; do
    echo "iter $i"
    val=$RANDOM
    ./cs_i2c w 0x40 0x0002 $val > /dev/null
    ret=$(./cs_i2c r 0x40 0x0002)
    data=$(echo "$ret" | grep "0x0002 = " | cut -d" " -f 3)
    if [[ "$val" != $((data)) ]]; then
        echo "val: $val  data: $data  data10: $((data))"
        exit 1
    fi
done

exit 0
