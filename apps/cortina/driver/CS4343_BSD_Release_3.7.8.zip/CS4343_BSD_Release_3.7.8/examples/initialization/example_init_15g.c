/** @file example_init_15g.c
 *****************************************************************************
 *
 * @brief
 *    This module provides an example of configuring the slice for 15.0G.
 *
 *****************************************************************************
 * @author
 *    Copyright (c) 2011-2015, Inphi Corporation
 *    All rights reserved.
 *    
 *    Redistribution and use in source and binary forms, with or without modification, 
 *    are permitted provided that the following conditions are met:
 *    
 *    1.	Redistributions of source code must retain the above copyright notice, 
 *       this list of conditions and the following disclaimer.
 *    
 *    2.	Redistributions in binary form must reproduce the above copyright notice, 
 *       this list of conditions and the following disclaimer in the documentation and/or 
 *       other materials provided with the distribution.
 *    
 *    3.	Neither the name of Inphi Corporation nor the names of its contributors 
 *       may be used to endorse or promote products derived from this software without 
 *       specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 *    THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 *    PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *    CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 *    PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 *    OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 *    WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 *    OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 *    ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *    API Version Number: 3.7.8
 ****************************************************************************/
#include "cs4224_api.h"

/**
 * The following example describes the process of configuring
 * the device to support 15.0G operation
 *
 * @return CS_OK on success, CS_ERROR on failure
 */

cs_status example_init_15g()
{
    cs_status status = CS_OK;
    cs4224_rules_t rules;
    cs_uint32 slice = 0;

    CS_PRINTF(("Initializing the chip in 15.0G mode\n"));
    
    /* First reset the ASIC to ensure it is in operational state.
       This will reset the entire device. Only the upper 24 bits of the
       slice parameter are used to reference the appropriate ASIC. The
       lower 8 bits are ignored. This method should only be called once
       when the ASIC is first powered on. */
    status |= cs4224_hard_reset(slice);
    if(CS_OK != status)
    {
        CS_TRACE(("ERROR trying to reset device\n"));
        return status;
    }

    /* Provision all ports of the chip for 15.0G mode. This
     * assumes:
     *   - Device configured for 156.25MHz reference clock
     *   - Microcode programmed automatically if not
     *     already programmed via EEPROM.
     * The rules_set_default() method does not actually configure
     * the ASIC, it just defaults the 'rules' structure for
     * the desired application.
     */ 
    status |= cs4224_rules_set_default(CS4224_TARGET_APPLICATION_15G, &rules);
 
    /* Assume an SR transceiver */
    rules.rx_if.dplx_line_edc_mode         = CS_HSIO_EDC_MODE_SR;
    rules.rx_if.dplx_line_eq.traceloss     = CS_HSIO_TRACE_LOSS_2dB;
    rules.tx_if.dplx_line_driver.traceloss = CS_HSIO_TRACE_LOSS_2dB;

    rules.rx_if.dplx_host_edc_mode         = CS_HSIO_EDC_MODE_SR;
    rules.rx_if.dplx_host_eq.traceloss     = CS_HSIO_TRACE_LOSS_2dB;
    rules.tx_if.dplx_host_driver.traceloss = CS_HSIO_TRACE_LOSS_2dB;
    
    for(slice = 0; slice < CS4224_MAX_NUM_SLICES(0); slice++)
    {
        status |= cs4224_slice_enter_operational_state(slice, &rules);
    }

    return status;
}


