/** @file example_init_2x2_switch.c
 *****************************************************************************
 *
 * @brief
 *    This module provides an example of a protection switch event.
 *
 *****************************************************************************
 * @author
 *    Copyright (c) 2011-2015, Inphi Corporation
 *    All rights reserved.
 *    
 *    Redistribution and use in source and binary forms, with or without modification, 
 *    are permitted provided that the following conditions are met:
 *    
 *    1.	Redistributions of source code must retain the above copyright notice, 
 *       this list of conditions and the following disclaimer.
 *    
 *    2.	Redistributions in binary form must reproduce the above copyright notice, 
 *       this list of conditions and the following disclaimer in the documentation and/or 
 *       other materials provided with the distribution.
 *    
 *    3.	Neither the name of Inphi Corporation nor the names of its contributors 
 *       may be used to endorse or promote products derived from this software without 
 *       specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 *    THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 *    PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *    CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 *    PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 *    OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 *    WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 *    OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 *    ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *    API Version Number: 3.7.8
 ****************************************************************************/
#include "cs4224_api.h"

/**
 *  The following example describes the process of configuring
 *  2 adjacent slices to support 10.3125G operation then issuing 
 *  a protection switch event.
 */
cs_status example_init_2x2_switch()
{
    cs_status status = CS_OK;
    cs4224_rules_t rules;
    /* Each switch pair must have it's own switch_state. Here we're only configuring
     * one switch-pair so we use a single variable */
    cs4224_switch_pair_state_t switch_state;
    /* lower slice of the slice-pair that we want to switch, in this case 0 & 1 */
    cs_uint32 slice = 0;
    /* all the interfaces (line/host) we are going to check for lock */
    cs4224_interface_t interfaces[] = { \
        { slice, CS4224_DPLX_HOST_MSEQ }, \
        { slice, CS4224_DPLX_LINE_MSEQ }, \
        { slice+1, CS4224_DPLX_HOST_MSEQ }, \
        { slice+1, CS4224_DPLX_LINE_MSEQ }  \
    };
    cs_uint16 intf_length = sizeof(interfaces)/sizeof(interfaces[0]);
    
    /* Don't need to memset the switch_state struct, only have to set initialized
     * to false and the switch API will do the rest
     */
    switch_state.initialized = FALSE;

    /* As of API release 3.4 low latency mode (analog switch) has an issue where
     * the elastic stores need to be reset after the CDR is locked. To not use
     * the low latency switch just do the following:
     */
    switch_state.low_latency_switching = FALSE;
    
    /* Regardless of whether we're using dynamic reconfig or not, we still MUST
     * reset the device into a known state as the very first thing we do. This
     * will reset the entire device, not just 'slice'.
     */
    status |= cs4224_hard_reset(slice);
    if(CS_OK != status)
    {
        CS_TRACE(("ERROR trying to reset device\n"));
        return status;
    }
    
    /* Provision 2 ports for 10.3125G mode. This assumes:
     *   - Device configured for 156.25MHz reference clock
     *   - No fractional divider
     *   - Microcode programmed automatically if not
     *     already programmed via EEPROM.
     * 
     * Host   Slice   Line
     * 10G <>---0---<> 10G
     * 
     * 
     * 
     * 10G <>---1---<> 10G
     */
    status |= cs4224_rules_set_default(CS4224_TARGET_APPLICATION_10G, &rules);

    /* For now the switch methods will automatically disable the auto-squelch feature
     * (see release notes for more info)
     */
    rules.unsquelch_driver = TRUE;

    CS_PRINTF(("Initializing ports %x and %x\n",slice, slice+1));
    status |= cs4224_slice_enter_operational_state(slice, &rules);
    status |= cs4224_slice_enter_operational_state(slice+1, &rules);
    if(CS_OK != status)
    {
        CS_TRACE(("ERROR in initialization\n"));
        return status;
    }

    /* Note that in the following methods, switch_state is being updated every time
     * with the current switch configuration. All you have to do is pass the struct
     * to every method.
     * 
     * Do NOT change the initialized var after you call these methods, as they will
     * not operate correctly and could leave the device in an unusable state.
     */
     

    /* perform a duplex 2x2 protection switch event on ports 0 and 1
     * 
     * Host   Slice   Line
     * 10G <>-+ 0 +-<> 10G
     *         \ /
     *          X
     *         / \
     * 10G <>-+ 1 +-<> 10G
     */
    status |= cs4224_switch_duplex(slice, CS4224_SWITCH_DUPLEX_SWITCH_2x2, &switch_state);
    
    if(switch_state.low_latency_switching)
    {
        /* When using low latency switching, we must get around the elastic store issue
         * by waiting for EDC converged (so the CDR has stabilized and data is flowing)
         * and then resetting/syncing the elastic stores
         */
        
        /* Wait for EDC converged on ALL interfaces (line/host) on the device */
        status |= cs4224_wait_for_links_ready(interfaces, intf_length, 500, 2000);
        if(CS_OK != status)
        {
            CS_TRACE(("ERROR waiting for links to lock\n"));
            return status;
        }
        
        /* then reset the analog elastic stores */
        status |= cs4224_switch_reset_analog_elsto(slice);
    }

    /* if you want you can disable the switch before going onto different switch
     * configs, but it is not necessary to do so. Feel free to switch from one to another
     */
    /*status |= cs4224_switch_duplex(slice, CS4224_SWITCH_DISABLE, &switch_state);*/

    /* Configure duplex broadcast 1 to 0
     * 
     * Host   Slice   Line
     * 10G --   0 +-<> 10G (Rx/Tx)
     *           /
     *          /
     *         /  
     * 10G <>-+-1----> 10G (Rx ignored)
     */
    status |= cs4224_switch_duplex(slice, CS4224_SWITCH_DUPLEX_BROADCAST_1_to_0, &switch_state);

    if(switch_state.low_latency_switching)
    {
        status |= cs4224_wait_for_links_ready(interfaces, intf_length, 500, 2000);
        if(CS_OK != status)
        {
            CS_TRACE(("ERROR waiting for links to lock\n"));
            return status;
        }
        status |= cs4224_switch_reset_analog_elsto(slice);
    }

    /* cancel the duplex 2x2 protection event on ports 0 and 1 */
    /*status |= cs4224_switch_duplex(slice, CS4224_SWITCH_DISABLE, &switch_state);*/

    /* Configure duplex broadcast 0 to 1
     * 
     * Host   Slice   Line
     * 10G <>-+-0----> 10G (Rx ignored)
     *         \  
     *          \
     *           \
     * 10G --   1 +-<> 10G (Rx/Tx)
     */
    status |= cs4224_switch_duplex(slice, CS4224_SWITCH_DUPLEX_BROADCAST_0_to_1, &switch_state);

    if(switch_state.low_latency_switching)
    {
        status |= cs4224_wait_for_links_ready(interfaces, intf_length, 500, 2000);
        if(CS_OK != status)
        {
            CS_TRACE(("ERROR waiting for links to lock\n"));
            return status;
        }
        status |= cs4224_switch_reset_analog_elsto(slice);
    }

    /* At the end of it all, lets revert back to the normal duplex state
     * 
     * Host   Slice   Line
     * 10G <>---0---<> 10G
     * 
     * 
     * 
     * 10G <>---1---<> 10G
     */
    status |= cs4224_switch_duplex(slice, CS4224_SWITCH_DISABLE, &switch_state);

    /* Make sure after disabling that everything is synced up if using low latency */
    if(switch_state.low_latency_switching)
    {
        status |= cs4224_wait_for_links_ready(interfaces, intf_length, 500, 2000);
        if(CS_OK != status)
        {
            CS_TRACE(("ERROR waiting for links to lock\n"));
            return status;
        }
        status |= cs4224_switch_reset_analog_elsto(slice);
    }

    return status;
}

