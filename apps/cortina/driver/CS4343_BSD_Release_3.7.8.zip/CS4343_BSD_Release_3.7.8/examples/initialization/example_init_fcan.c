/** @file example_init_fcan.c
 *****************************************************************************
 *
 * @brief
 *    This module provides an exaSmple of configuring the slice for FC-AN.
 *    FC Auto-Negotiation functionality is supported on the duplex parts only.
 *
 *****************************************************************************
 * @author
 *    Copyright (c) 2011-2015, Inphi Corporation
 *    All rights reserved.
 *    
 *    Redistribution and use in source and binary forms, with or without modification, 
 *    are permitted provided that the following conditions are met:
 *    
 *    1.	Redistributions of source code must retain the above copyright notice, 
 *       this list of conditions and the following disclaimer.
 *    
 *    2.	Redistributions in binary form must reproduce the above copyright notice, 
 *       this list of conditions and the following disclaimer in the documentation and/or 
 *       other materials provided with the distribution.
 *    
 *    3.	Neither the name of Inphi Corporation nor the names of its contributors 
 *       may be used to endorse or promote products derived from this software without 
 *       specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 *    THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 *    PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *    CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 *    PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 *    OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 *    WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 *    OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 *    ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *    API Version Number: 3.7.8
 ****************************************************************************/
#include "cs4224_api.h"


/**
 * The following example describes the process of configuring
 * the device to support FC-AN operation
 * 
 * Note that in order for training to complete there must be
 * a valid PCS signal present on the XFI interface. Generally
 * this will be PCS idles. This is required to lock the XFI
 * receiver to provide a transmit reference to transmit
 * training frames. Training will not proceed until the XFI
 * interface is locked. The ASIC will stay in training waiting
 * for the XFI interface to lock until the link fail inhibit timer
 * has expired.

 */

cs_status example_init_fcan()
{
    cs_status status = CS_OK;
    cs_uint32 slice = 0;
    e_cs4224_fcan_an_status_t an_done[8]  = 
        {CS4224_FCAN_AN_NOT_DONE, CS4224_FCAN_AN_NOT_DONE, 
         CS4224_FCAN_AN_NOT_DONE, CS4224_FCAN_AN_NOT_DONE,
         CS4224_FCAN_AN_NOT_DONE, CS4224_FCAN_AN_NOT_DONE, 
         CS4224_FCAN_AN_NOT_DONE, CS4224_FCAN_AN_NOT_DONE};
    e_cs4224_fcan_data_rate_t an_rates[8] =
        {CS4224_FCAN_DATA_RATE_DISABLED, CS4224_FCAN_DATA_RATE_DISABLED,
         CS4224_FCAN_DATA_RATE_DISABLED, CS4224_FCAN_DATA_RATE_DISABLED,
         CS4224_FCAN_DATA_RATE_DISABLED, CS4224_FCAN_DATA_RATE_DISABLED,
         CS4224_FCAN_DATA_RATE_DISABLED, CS4224_FCAN_DATA_RATE_DISABLED};

    cs4224_rules_t rules;

    /* First reset the ASIC to ensure it is in operational state.
       This will reset the entire device. Only the upper 24 bits of the
       slice parameter are used to reference the appropriate ASIC. The
       lower 8 bits are ignored. This method should only be called once
       when the ASIC is first powered on. */
    status |= cs4224_hard_reset(slice);
    if(CS_OK != status)
    {
        CS_TRACE(("ERROR trying to reset device\n"));
        return status;
    }

    /* Setup the rules for FC-AN */
    status |= cs4224_rules_set_default(CS4224_TARGET_APPLICATION_FCAN, &rules);

    /* Advertise the data-rate capabilities
     * Note: Some restrictions apply to the advertised rates. They are:
     *   - No more than 3 rates can be advertised at one time.
     *   - The 3 advertised rates must be in series such as
     *       1G, 2G, 4G
     *       2G, 4G, 8G
     *       4G, 8G, 16G
     */
    rules.fcan.data_rates = CS4224_FCAN_DATA_RATE_16G | 
                            CS4224_FCAN_DATA_RATE_8G  |
                            CS4224_FCAN_DATA_RATE_4G;

    rules.ref_clk_rate                      = 106.25;

    /* Advertized capabilities */
    rules.fcan.speed_negotiation_support    = TRUE; 
    rules.fcan.training_protocol_support    = TRUE;  /* applies to 16G FC only */
    rules.fcan.fec_capable                  = TRUE;  /* applies to 16G FC only */
    rules.fcan.fec_request                  = TRUE;  /* applies to 16G FC only */
    rules.fcan.transmitter_fixed            = FALSE; /* applies to 16G FC only */

    /* SR and FCAN DFE modes are supported on the line side.
     * 8G and 16G data-rates are automaticaly configured for DFE mode, data-rates
     * lower than 8G automatically configured for SR mode.   
     */
    rules.rx_if.dplx_line_edc_mode          = CS_HSIO_EDC_MODE_FCAN;
    /* SR and DFE modes are supported on the host side */
    rules.rx_if.dplx_host_edc_mode          = CS_HSIO_EDC_MODE_SR;

    /* trace loss settings */
    rules.tx_if.dplx_line_driver.traceloss  = CS_HSIO_TRACE_LOSS_0dB;
    rules.tx_if.dplx_host_driver.traceloss  = CS_HSIO_TRACE_LOSS_0dB;
    rules.rx_if.dplx_line_eq.traceloss      = CS_HSIO_TRACE_LOSS_0dB;
    rules.rx_if.dplx_host_eq.traceloss      = CS_HSIO_TRACE_LOSS_0dB;

    /* when configuring multiple slices at once, it's more efficient to not
     * have enter_operational_state wait for FC-AN to complete. Instead,
     * we will manually use the wait_for_an method after configuring.
     */
    rules.fcan.wait_for_an_done             = FALSE;

    /* configure all (duplex) slices */
    for(slice = 0; slice < CS4224_MAX_NUM_SLICES(0); slice++)
    {
        status |= cs4224_slice_enter_operational_state(slice, &rules);
    }

    /* poll all slices for AN to complete and get the results, if any */
    for (slice = 0; slice < CS4224_MAX_NUM_SLICES(0); slice++)
    {
        /* block for 10 seconds waiting for AN to complete */
        an_done[slice] = cs4224_fcan_wait_for_an_with_timeout(slice, 10, &(an_rates[slice]));
        /* or block forever waiting for AN to complete */
        /* an_done[slice] = cs4224_fcan_wait_for_an(slice, &(an_rates[slice]));*/
    }

    /* configure all slices to their negotiated results, if available */
    for (slice = 0; slice < CS4224_MAX_NUM_SLICES(0); slice++)
    {
        if (an_done[slice] == CS4224_FCAN_AN_DONE)
        {
            rules.fcan.negotiated_rate = an_rates[slice];
            status |= cs4224_fcan_init_fc_post_an(slice, &rules);
        }
        else
        {
            /* dump error message indicating slice did not complete AN */
            CS_TRACE(("ERROR: FCAN did not complete on slice %d",slice));
            status |= CS_ERROR;
        }
    }

    return status;
}


