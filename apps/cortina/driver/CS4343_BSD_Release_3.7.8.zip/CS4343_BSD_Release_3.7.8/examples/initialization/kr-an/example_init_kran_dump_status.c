/** @file example_init_kran_dump_status.c
 *****************************************************************************
 *
 * @brief
 *    This module provides an example of displaying the KR-AN status of up to 
 *    8 slices simultaneously.
 *    Note: KR functionality is supported on the cs4343 (duplex) part only.
 *
 *****************************************************************************
 * @author
 *    Copyright (c) 2011-2015, Inphi Corporation
 *    All rights reserved.
 *    
 *    Redistribution and use in source and binary forms, with or without modification, 
 *    are permitted provided that the following conditions are met:
 *    
 *    1.	Redistributions of source code must retain the above copyright notice, 
 *       this list of conditions and the following disclaimer.
 *    
 *    2.	Redistributions in binary form must reproduce the above copyright notice, 
 *       this list of conditions and the following disclaimer in the documentation and/or 
 *       other materials provided with the distribution.
 *    
 *    3.	Neither the name of Inphi Corporation nor the names of its contributors 
 *       may be used to endorse or promote products derived from this software without 
 *       specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 *    THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 *    PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *    CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 *    PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 *    OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 *    WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 *    OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 *    ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *    API Version Number: 3.7.8
 ****************************************************************************/
#include "cs4224_api.h"

     
/**
 * The following examples describes the process of calling display 
 * methods to display KR-AN status.
 * 
 * The method cs4224_kran_status_summary displays the KR-AN status of
 * up to 8 slices whereas the cs4224_kran_status method displays the KR-AN
 * status of a single slice
 */

cs_status example_init_kran_dump_status()
{
    cs_status status = CS_OK;
    cs_uint32 slice = 0;

    /* The following method displays the KR-AN status of all slices of the   */
    /* selected device identified by the upper 24 bits of the slice argument */

    status |= cs4224_kran_status_summary(slice);

    /* Example output

KR-AN Status
============
ASIC Status
  Pin Status:    0x6f81
  Asic Rev:      0x1003
  Api Version:   0x282b
  Die 0 Temp:    62.78 C
  Die 1 Temp:    61.39 C
  ucode Version: (yyyy/mmdd/hhmm)2013/0711/1140
Slices                         0          1          2          3          4          5          6          7
AN Negotiated Results
  1000Base-KX:               n/a        OFF        n/a        n/a        n/a        n/a        OFF        n/a
  10GBase-KR:                n/a         ON        n/a        n/a        n/a        n/a         ON        n/a
  40GBase-KR4:               n/a        OFF        n/a        n/a        n/a        n/a        OFF        n/a
  40GBase-CR4:               n/a        OFF        n/a        n/a        n/a        n/a        OFF        n/a
  10GBase-KX4:               n/a        OFF        n/a        n/a        n/a        n/a        OFF        n/a
  FEC Ability:               n/a         ON        n/a        n/a        n/a        n/a         ON        n/a
  Parallel Detect:           n/a        OFF        n/a        n/a        n/a        n/a        OFF        n/a
  Remote Fault:              n/a        OFF        n/a        n/a        n/a        n/a        OFF        n/a
  Pause:                     n/a        OFF        n/a        n/a        n/a        n/a        OFF        n/a
Clause 73 Auto-Negotiation
  AN Good Check:            True      False       True       True       True       True      False       True
  AN Good:                 False       True      False      False      False      False       True      False
  AN Failure:               True      False       True       True       True       True      False       True
  AN Enabled:              False       True      False      False      False      False       True      False
  AN Pages Received:     Unknown        Yes    Unknown    Unknown    Unknown    Unknown        Yes    Unknown
  AN Retries:                n/a       0092        n/a        n/a        n/a        n/a       0092        n/a
AN State Machine History
  AN SM Current:           UNDEF    AN_GOOD      UNDEF      UNDEF      UNDEF      UNDEF    AN_GOOD      UNDEF
  AN SM Prev 1:            UNDEF AN_GOODCHK      UNDEF      UNDEF      UNDEF      UNDEF AN_GOODCHK      UNDEF
  AN SM Prev 2:            UNDEF   COMP_ACK      UNDEF      UNDEF      UNDEF      UNDEF   COMP_ACK      UNDEF
  AN SM Prev 3:            UNDEF ACK_DETECT      UNDEF      UNDEF      UNDEF      UNDEF ACK_DETECT      UNDEF
Clause 72 Startup/Training Protocol
  TP Failure:              False       True      False      False      False      False       True      False
  TP Complete:              True      False       True       True       True       True      False       True
  TP FRAME Lock:           False      False      False      False      False      False      False      False
  TP Enabled:              False       True      False      False      False      False       True      False
  TP In Progress:          False      False      False      False      False      False      False      False
Training State Machine History
  TP SM Current:      TRAIN_LOCL TRAIN_FAIL TRAIN_LOCL TRAIN_LOCL TRAIN_LOCL TRAIN_LOCL TRAIN_FAIL TRAIN_LOCL
  TP SM Prev 1:       TRAIN_FAIL SEND_TRAIN TRAIN_FAIL TRAIN_FAIL TRAIN_FAIL TRAIN_FAIL SEND_TRAIN TRAIN_FAIL
  TP SM Prev 2:       TRAIN_FAIL       INIT TRAIN_FAIL TRAIN_FAIL TRAIN_FAIL TRAIN_FAIL       INIT TRAIN_FAIL
  TP SM Prev 3:       LINK_READY       INIT LINK_READY LINK_READY LINK_READY LINK_READY       INIT LINK_READY
  TP SM Prev 4:       TRAIN_FAIL       INIT TRAIN_FAIL TRAIN_FAIL TRAIN_FAIL TRAIN_FAIL       INIT TRAIN_FAIL
Tap Values
  Override enabled:        False      False      False      False      False      False      False      False
  Pre:                     47834      00031      47834      47834      47834      47834      00031      47834
  Main:                    47834      00043      47834      47834      47834      47834      00043      47834
  Post:                    47834      00062      47834      47834      47834      47834      00062      47834
Clause 74 FEC
  FEC Tx Sync:             False       True      False      False      False      False       True      False
  FEC Rx Sync:             False       True      False      False      False      False       True      False
  10G PCS Rx Sync:         False       True      False      False      False      False       True      False
  10G PCS Rx BER:           True      False       True       True       True       True      False       True
FEC Statistics
  Tx Total Blocks:           n/a   23023595        n/a        n/a        n/a        n/a   23640190        n/a
  Rx Total Blocks:           n/a     937450        n/a        n/a        n/a        n/a     937536        n/a
  Rx Corr. Blocks:           n/a          0        n/a        n/a        n/a        n/a          0        n/a
  Rx Uncorr. Blocks:         n/a          0        n/a        n/a        n/a        n/a          0        n/a
  Rx Zero Bit Er Bks:        n/a          0        n/a        n/a        n/a        n/a          0        n/a
  Rx One Bit Er Bks:         n/a          0        n/a        n/a        n/a        n/a          0        n/a
Line Device Status
  CDR Lock:                False       True      False      False      False      False       True      False
  MSEQ Bank:                   3          1          3          3          3          3          1          3
  MSEQ PC:                 0x000      0x1d8      0x000      0x000      0x000      0x000      0x11c      0x000
  MSEQ Stalled:             True      False       True       True       True       True      False       True
  Squelched Enabled:       False       True      False      False      False      False       True      False
  Squelched:                True      False       True       True       True       True      False       True
  Power Saving Enab:        True      False       True       True       True       True      False       True
  POWER_DOWN_LSB:         0x0000     0x0000     0x0000     0x0000     0x03ff     0x03ff     0x0000     0x03ff
  RX_CPA:                 0x80dd     0x0099     0x80dd     0x80dd     0x80dd     0x80dd     0x0099     0x80dd
  MSEQ_SERDES:            0x0030     0x0030     0x0030     0x0030     0x0030     0x0030     0x0030     0x0030
  FUNCEN:                 0x0000     0x2024     0x0000     0x0000     0x0000     0x0000     0x2024     0x0000
  CLKDIV_CTRL:            0x3005     0x3005     0x3005     0x3005     0x3005     0x3005     0x3005     0x3005
Host Device Status
  CDR Lock:                False       True      False      False      False      False       True      False
  MSEQ Bank:                   3          1          3          3          3          3          1          3
  MSEQ PC:                 0x000      0x1d8      0x000      0x000      0x000      0x000      0x03c      0x000
  MSEQ Stalled:             True      False       True       True       True       True      False       True
  Squelched Enabled:       False      False      False      False      False      False      False      False
  Squelched:                True      False       True       True       True       True      False       True
  Power Saving Enab:        True      False       True       True       True       True      False       True
  POWER_DOWN_LSB:         0x01f7     0x0000     0x01f7     0x01f7     0x03ff     0x03ff     0x0000     0x03ff
  RX_CPA:                 0x80dd     0x00bb     0x80dd     0x80dd     0x80dd     0x80dd     0x00bb     0x80dd
  MSEQ_SERDES:            0x0030     0x0030     0x0030     0x0030     0x0030     0x0030     0x0030     0x0030
  FUNCEN:                 0x0000     0x0000     0x0000     0x0000     0x0000     0x0000     0x0000     0x0000
  CLKDIV_CTRL:            0x3005     0x3005     0x3005     0x3005     0x3005     0x3005     0x3005     0x3005
*/

    /* The following method displays the KR-AN status of a single slice of the   */
    /* selected device identified by the slice argument */

    status |= cs4224_kran_status(slice);

    /* Example output 

KR-AN Status for K2 Slice 1
============================
ASIC Status
    pin_status:    6f81     asic_rev:      1003
    api_version:   282b     ucode_vers:    11/07/2013
    line_func_en:  101      host_func_en:  1
Clause 73 Auto-Negotiation                   AN State Machine History
    AN Good Check:      False                    Current:               AN_GOOD
    AN Good:            True                     Previous 1:         AN_GOODCHK
    AN Failure:         False                    Previous 2:           COMP_ACK
    Enabled:            yes                      Previous 3:         ACK_DETECT
Clause 72 Startup/Training Protocol          Training State Machine History
    TP Failure:         False                    Current:                  INIT
    TP Complete:        False                    Previous 1:               INIT
    TP Frame Lock:      False                    Previous 2:               INIT
    Enabled:            no                       Previous 3:               INIT
    In Progress:        no                       Previous 4:               INIT
AN Negotiated Results:
  AN retries:   1 (SPARE22_LSB)    AN page received:   Yes
  Results:
    1000Base-KX:        ON
    10GBase-KR:         OFF
    40GBase-KR4:        OFF
    40GBase-CR4:        OFF
    FEC Ability:        OFF
    Parallel Detect:    OFF
    Remote Fault:       OFF
    Pause:              0x3
    Link Partner Advertised:
        1000Base-KX:    ON
        10GBase-KX4:    OFF
        10GBase-KR:     OFF
        40GBase-KR4:    OFF
        40GBase-CR4:    OFF
        100GBase-CR10:  OFF
Tap Values:
    Override enabled:    0
    Pre:                 0 (CTRLB.STX_PRE_PEAK)
    Main:               43 (CTRLA.STX_LEVEL)
    Post:                1 (CTRLB.STX_POST_PEAK)
Performance:
    SNR:                0
    Temp:               57.22 C
    CMODE_RES:          4
    ResetCounter:       0
Clause 74 FEC:
    FEC Tx Sync:        False
    FEC Rx Sync:        False
    10G PCS Rx Sync:    False
    10G PCS Rx BER:     False
Statistics:
    FEC Not Negotiated, No FEC Stats
Device Status:
             Line                  Host
             --------              --------
    Lock:    True  (  41)          True  (  41)
    Bank:    2                     2
    PC:      80cc,80cf,80d1,80d1   0068,0068,0068,0068,0068
    Stalled: False                 False
    Squelch: 0                     0
    ClkDiv:  3034                  3034
    SquelEn: ON                    OFF
    PwrSav:  OFF                   OFF
    PwrDown: 65                    65
    RX_CPA:  99                    dd
    MS_SRDS: 30                    30
Line Side MSEQ Spare Registers:
    SPAREnn=(MSW/LSW) 00=(0x0007/0x0020) 01=(0x0000/0x0005) 02=(0x1b50/0x2250) 03=(0x0000/0x0000) 04=(0x0000/0x0000)
    SPAREnn=(MSW/LSW) 05=(0x0000/0x0000) 06=(0x0000/0x000f) 07=(0x0020/0x0014) 08=(0x0000/0x0000) 09=(0x0012/0x0000)
    SPAREnn=(MSW/LSW) 10=(0x0000/0x0000) 11=(0x807f/0xfffe) 12=(0x4000/0x0004) 13=(0x0000/0x0000) 14=(0x0000/0x0000)
    SPAREnn=(MSW/LSW) 15=(0x0000/0x0000) 16=(0x0000/0x0000) 17=(0x0000/0x0000) 18=(0x0000/0x0002) 19=(0x0000/0x0000)
    SPAREnn=(MSW/LSW) 20=(0x0000/0x0000) 21=(0x0000/0x0000) 22=(0x0000/0x0001) 23=(0x0000/0x0000) 24=(0x0000/0x0000)
    SPAREnn=(MSW/LSW) 25=(0x0000/0x0002) 26=(0x0000/0x0209) 27=(0x006c/0x04b5) 28=(0x0000/0x0020)
Host Side MSEQ Spare Registers:
    SPAREnn=(MSW/LSW) 00=(0x0000/0x0000) 01=(0x0000/0x0014) 02=(0x0000/0x0000) 03=(0x0000/0x0000) 04=(0x0000/0x3000)
    SPAREnn=(MSW/LSW) 05=(0x0000/0x0000) 06=(0x0000/0x0000) 07=(0x0000/0x0000) 08=(0x0000/0x0000) 09=(0x0000/0x0000)
    SPAREnn=(MSW/LSW) 10=(0x0000/0x0000) 11=(0x0000/0x0000) 12=(0x4000/0x0041) 13=(0x0000/0x0000) 14=(0x0000/0x0000)
    SPAREnn=(MSW/LSW) 15=(0x0000/0x0000) 16=(0x0000/0x0000) 17=(0x0000/0x0000) 18=(0x0000/0x0007) 19=(0x0000/0x0000)
    SPAREnn=(MSW/LSW) 20=(0x0000/0x0000) 21=(0x0000/0x0000) 22=(0x0000/0x0000) 23=(0x0000/0x0000) 24=(0x0000/0x0000)
    SPAREnn=(MSW/LSW) 25=(0x0000/0x0000) 26=(0x0000/0x0022) 27=(0x0000/0x0001) 28=(0x0000/0x0000)
*/

    return status;
}

