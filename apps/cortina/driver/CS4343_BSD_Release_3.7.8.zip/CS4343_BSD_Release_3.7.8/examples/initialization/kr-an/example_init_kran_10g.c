/** @file example_init_kran_10g.c
 *****************************************************************************
 *
 * @brief
 *    This module provides an example of configuring the slice for KR-AN.
 *    Note: KR Auto-Negotiation functionality is supported on the cs4343
 *    (duplex) part only.
 *
 *****************************************************************************
 * @author
 *    Copyright (c) 2011-2015, Inphi Corporation
 *    All rights reserved.
 *    
 *    Redistribution and use in source and binary forms, with or without modification, 
 *    are permitted provided that the following conditions are met:
 *    
 *    1.	Redistributions of source code must retain the above copyright notice, 
 *       this list of conditions and the following disclaimer.
 *    
 *    2.	Redistributions in binary form must reproduce the above copyright notice, 
 *       this list of conditions and the following disclaimer in the documentation and/or 
 *       other materials provided with the distribution.
 *    
 *    3.	Neither the name of Inphi Corporation nor the names of its contributors 
 *       may be used to endorse or promote products derived from this software without 
 *       specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 *    THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 *    PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *    CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 *    PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 *    OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 *    WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 *    OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 *    ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *    API Version Number: 3.7.8
 ****************************************************************************/
#include "cs4224_api.h"

     
/**
 * The following example describes the process of configuring
 * the device to support 10G Ethernet Backplane KR+Auto Negotiation
 * operation.
 *
 * It is also possible to support KR without Auto-Negotiation.
 * Please refer to the 10G backplane example in the initialization directory
 * for configurations where training and auto-negotiation are not required.
 *
 * Note that in order for training to complete there must be
 * a valid 10G PCS signal present on the XFI interface. Generally
 * this will be PCS idles. This is required to lock the XFI
 * receiver to provide a transmit reference to transmit
 * training frames. Training will not proceed until the XFI
 * interface is locked. The ASIC will stay in training waiting
 * for the XFI interface to lock until the link fail inhibit timer
 * has expired.
 */
cs_status example_init_kran()
{
    cs_status status = CS_OK;
    cs_uint32 slice = 0;

    /* Need to track the status of each slice since we're performing
     * KR-AN on each slice */
    e_cs4224_kran_an_status_t an_done[8]  = 
        {CS4224_KRAN_AN_NOT_DONE, CS4224_KRAN_AN_NOT_DONE, 
         CS4224_KRAN_AN_NOT_DONE, CS4224_KRAN_AN_NOT_DONE,
         CS4224_KRAN_AN_NOT_DONE, CS4224_KRAN_AN_NOT_DONE, 
         CS4224_KRAN_AN_NOT_DONE, CS4224_KRAN_AN_NOT_DONE};
    cs4224_kran_results_t_s   an_results[8];

    cs4224_rules_t            rules;
    
    /* First reset the ASIC to ensure it is in operational state.
       This will reset the entire device. Only the upper 24 bits of the
       slice parameter are used to reference the appropriate ASIC. The
       lower 8 bits are ignored. This method should only be called once
       when the ASIC is first powered on. */
    cs4224_hard_reset(slice);

    /* Setup the rules for KR */
    status |= cs4224_rules_set_default(CS4224_TARGET_APPLICATION_KRAN, &rules);

    /* setup rules for the line side, EDC mode must be 10G_BP */
    rules.rx_if.dplx_line_edc_mode         = CS_HSIO_EDC_MODE_10G_BP;

    /* setup rules for the host side, EDC mode can be one of:
     *    CS_HSIO_EDC_MODE_CX1,
     *    CS_HSIO_EDC_MODE_SR,
     *    CS_HSIO_EDC_MODE_ZR,
     *    CS_HSIO_EDC_MODE_DWDM or
     *    CS_HSIO_EDC_MODE_10G_BP */
    rules.rx_if.dplx_host_edc_mode         = CS_HSIO_EDC_MODE_CX1;
    rules.rx_if.dplx_host_eq.traceloss     = CS_HSIO_TRACE_LOSS_6dB;
    rules.tx_if.dplx_host_driver.traceloss = CS_HSIO_TRACE_LOSS_6dB;

    /* advertise the following KR data-rate capabilities */
    rules.kran.data_rates       = CS4224_KRAN_DATA_RATE_1G |
                                  CS4224_KRAN_DATA_RATE_10G;

    rules.kran.fec_ability_f0   = TRUE;  /* FEC ability flag (F0) */
    rules.kran.fec_requested_f1 = TRUE;  /* FEC requested flag (F1) */
    rules.kran.pause_ability_c0 = FALSE; /* Pause ability flag (C0) */
    rules.kran.pause_ability_c1 = FALSE; /* Pause ability flag (C1) */
    rules.kran.remote_fault_d13 = FALSE; /* Remote Fault flag (D13) */
    rules.kran.allow_training   = TRUE;  /* Training enable flag */
    rules.kran.wait_for_an_done = FALSE; /* Wait for KR-AN to complete flag. If this
                                            is set to TRUE then enter_operational_state_kran
                                            will block until AN + training has completed.
                                            This could block for a long time if the link
                                            does not come up right away. */

    /* configure all (duplex) slices for KR-AN */
    for(slice = 0; slice < CS4224_MAX_NUM_SLICES(0); slice++)
    {
        status |= cs4224_slice_enter_operational_state_kran(slice, &rules);
    }

    /* poll all slices for AN to complete and get the results, if any */
    for (slice = 0; slice < CS4224_MAX_NUM_SLICES(0); slice++)
    {
        /* block for 100 seconds waiting for AN to complete */
        an_done[slice] = cs4224_kran_wait_for_an_with_timeout(slice, 100, &an_results[slice]);
        /* or block forever waiting for AN to complete */
        /* an_done[slice] = cs4224_kran_wait_for_an(slice, &an_results[slice], (void *)NULL);*/
    }

    /* configure all slices to their negotiated results, if available */
    for (slice = 0; slice < CS4224_MAX_NUM_SLICES(0); slice++)
    {
        if (an_done[slice] == CS4224_KRAN_AN_DONE)
        {
            /* if negotiated data-rate is 1G */
            if (an_results[slice].bp_1000kx)
            {
                /* wait for the host side mate to generate a 1G clock before proceding */
            }

            status |= cs4224_kran_init_kr_post_an(slice, &rules, &an_results[slice]);
        }
        else
        {
            /* dump error message indicating slice did not complete AN */
        }
    }

    return status;
}

