/** @file example_init_kran_40g.c
 *****************************************************************************
 *
 * @brief
 *    This module provides an example of configuring 4 slices for 40G KR-AN.
 *    Note: KR Auto-Negotiation functionality is supported on the
 *    cs4343 (duplex) part only.
 *
 *****************************************************************************
 * @author
 *    Copyright (c) 2011-2015, Inphi Corporation
 *    All rights reserved.
 *    
 *    Redistribution and use in source and binary forms, with or without modification, 
 *    are permitted provided that the following conditions are met:
 *    
 *    1.	Redistributions of source code must retain the above copyright notice, 
 *       this list of conditions and the following disclaimer.
 *    
 *    2.	Redistributions in binary form must reproduce the above copyright notice, 
 *       this list of conditions and the following disclaimer in the documentation and/or 
 *       other materials provided with the distribution.
 *    
 *    3.	Neither the name of Inphi Corporation nor the names of its contributors 
 *       may be used to endorse or promote products derived from this software without 
 *       specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 *    THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 *    PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *    CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 *    PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 *    OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 *    WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 *    OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 *    ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *    API Version Number: 3.7.8
 ****************************************************************************/
#include "cs4224_api.h"

     
/**
 * The following example describes the process of configuring
 * the device to support 40G Ethernet KR+Auto Negotiation operation.
 *
 * It is also possible to support Ethernet without KR. Please refer
 * to the 40G backplane example in initialization directory.
 *
 * This is a 4x10 configuration where 4 lanes are ganged together to
 * form a 40G link. AN only occurs on a single slice called the
 * master slice.
 *
 * The master slice can be any one of 4 slices and is identified as
 * the first argument to the method cs4224_slice_enter_operational_state_kran.
 * Only the master slice performs auto-negotiation. The remaining 3 slices
 * only perform training. Therefore it is important that the lane mapping
 * on the master slice must match the lane mapping on the remote end.
 *
 *    CS4343                                      Link Partner
 *    ======                                      ============
 *      Slice 0 (Master) ---- AN+Training ------  Lane N (Master)
 *      Slice 1 (Slave)  ---- Training only ----  Lane N+1 (Slave)
 *      Slice 2 (Slave)  ---- Training only ----  Lane N+2 (Slave)
 *      Slice 3 (Slave)  ---- Training only ----  Lane N+3 (Slave)
 *
 * If slice 0 doesn't match up with the remote partner then AN can't
 * occur and CS4343 will constantly be waiting for DME pages from
 * the remote partner.
 *
 * Note that in order for training to complete there must be
 * a valid 10G PCS signal present on the XFI interface. Generally
 * this will be PCS idles. This is required to lock the XFI
 * receiver to provide a transmit reference to transmit
 * training frames. Training will not proceed until the XFI
 * interface is locked. The ASIC will stay in training waiting
 * for the XFI interface to lock until the link fail inhibit timer
 * has expired.
 */
cs_status example_init_kran_40g()
{
    cs_status status = CS_OK;
    e_cs4224_kran_an_status_t an_done;
    cs4224_kran_results_t_s   an_results;
    cs4224_rules_t            rules;
    cs_uint32                 master_slice = 3;

    /* First reset the ASIC to ensure it is in operational state.
       This will reset the entire device. Only the upper 24 bits of the
       slice parameter are used to reference the appropriate ASIC. The
       lower 8 bits are ignored. This method should only be called once
       when the ASIC is first powered on. */
    cs4224_hard_reset(master_slice);

    /* Setup the rules for 10G KR */
    status |= cs4224_rules_set_default(CS4224_TARGET_APPLICATION_KRAN, &rules);

    /* setup rules for the line side, the EDC mode must be 10G_BP 
     * for KR to work properly */
    rules.rx_if.dplx_line_edc_mode         = CS_HSIO_EDC_MODE_10G_BP;

    /* setup rules for the host side, EDC mode can be one of:
     *    CS_HSIO_EDC_MODE_CX1,
     *    CS_HSIO_EDC_MODE_SR
     *    CS_HSIO_EDC_MODE_ZR
     *    CS_HSIO_EDC_MODE_DWDM
     *    CS_HSIO_10G_BP
     */
    rules.rx_if.dplx_host_edc_mode         = CS_HSIO_EDC_MODE_CX1;
    rules.rx_if.dplx_host_eq.traceloss     = CS_HSIO_TRACE_LOSS_6dB;
    rules.tx_if.dplx_host_driver.traceloss = CS_HSIO_TRACE_LOSS_6dB;

    /* advertise the following abilities */
    rules.kran.data_rates       = CS4224_KRAN_DATA_RATE_BP_40G;   /* 40GBASE-KR4 Backplane or */
                               /* CS4224_KRAN_DATA_RATE_FP_40G;*/ /* 40GBASE-CR4 Copper Cable */

    rules.kran.fec_ability_f0   = TRUE;  /* FEC ability flag (F0) */
    rules.kran.fec_requested_f1 = TRUE;  /* FEC requested flag (F1) */
    rules.kran.pause_ability_c0 = FALSE; /* Pause ability flag (C0) */
    rules.kran.pause_ability_c1 = FALSE; /* Pause ability flag (C1) */
    rules.kran.remote_fault_d13 = FALSE; /* Remote Fault flag (D13) */
    rules.kran.allow_training   = TRUE;  /* Training enable flag */
    rules.kran.wait_for_an_done = FALSE; /* Wait for KR-AN to complete flag. If this
                                            is set to TRUE then enter_operational_state_kran
                                            will block until AN + training has completed. This
                                            could block for a long time if the link does not
                                            come up right away. */

    /* configure the 4 slices for 40G KR, return before polling for AN */
    status |= cs4224_slice_enter_operational_state_kran(master_slice, &rules);

    /* poll the master slice (max wait is 100 seconds) for AN to complete and get the results, if any */
    an_done = cs4224_kran_wait_for_an_with_timeout(master_slice, 100, &an_results);
    /* or block forever waiting for AN to complete */
    /* an_done = cs4224_kran_wait_for_an(master_slice, &an_results, (void *)NULL);*/

    if (an_done == CS4224_KRAN_AN_NOT_DONE)
    {
        /* dump error message indicating master_slice did not complete AN */
        status = CS_ERROR;
    }

    return status;
}

