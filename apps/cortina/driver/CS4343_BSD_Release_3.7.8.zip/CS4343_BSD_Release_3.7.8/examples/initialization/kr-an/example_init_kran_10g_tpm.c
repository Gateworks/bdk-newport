/** @file example_init_kran_10g_tpm.c
 *****************************************************************************
 *
 * @brief
 *    This module provides an example of configuring the slice for KR-AN with
 *    two-pass-mode.
 *    Note: KR Auto-Negotiation functionality is supported on the cs4343
 *    (duplex) part only.
 *
 *****************************************************************************
 * @author
 *    Copyright (c) 2011-2015, Inphi Corporation
 *    All rights reserved.
 *    
 *    Redistribution and use in source and binary forms, with or without modification, 
 *    are permitted provided that the following conditions are met:
 *    
 *    1.	Redistributions of source code must retain the above copyright notice, 
 *       this list of conditions and the following disclaimer.
 *    
 *    2.	Redistributions in binary form must reproduce the above copyright notice, 
 *       this list of conditions and the following disclaimer in the documentation and/or 
 *       other materials provided with the distribution.
 *    
 *    3.	Neither the name of Inphi Corporation nor the names of its contributors 
 *       may be used to endorse or promote products derived from this software without 
 *       specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 *    THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 *    PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *    CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 *    PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 *    OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 *    WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 *    OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 *    ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *    API Version Number: 3.7.8
 ****************************************************************************/
#include "cs4224_api.h"

     
/**
 * The following example describes the process of configuring
 * the device to support 10G Ethernet Backplane KR+Auto Negotiation
 * operation, with two pass mode.
 *
 * It is also possible to support KR without Auto-Negotiation.
 * Please refer to the 10G backplane example in the initialization directory
 * for configurations where training and auto-negotiation are not required.
 *
 * This example uses a single CS4343 chip to simulate the two 'link partners'
 * (slices 0 & 7) and the two CS4343 devices setting up the optical link (slices
 * 3 & 4).
 * 
 * intf:       line                 host                 line
 * Slice 0 <-backplane-> Slice 3 <-optical-> Slice 4 <-backplane-> Slice 7
 * 
 * Note that in order for training to complete there must be
 * a valid 10G PCS signal present on the XFI interfaces of slices 0 and 7.
 * Generally this will be PCS idles. This is required to lock the XFI
 * receiver to provide a transmit reference to transmit
 * training frames. Training will not proceed until the XFI
 * interface is locked. The ASIC will stay in training waiting
 * for the XFI interface to lock until the link fail inhibit timer
 * has expired.
 */
cs_status example_init_kran_tpm()
{
    cs_status status = CS_OK;
    cs_uint16 i = 0;

    /* Need to track the status of each slice since we're performing
     * KR-AN on each slice */
    cs_uint32 slices[] = { 0, 3, 4, 7 };
    cs_uint16 num_slices = sizeof(slices)/sizeof(*slices);
    /* in C99 mode you should be able to use the following as an_done[num_slices] */
    e_cs4224_kran_an_status_t an_done[4];
    cs4224_kran_results_t_s   an_results[4];

    cs4224_rules_t            rules;
    
    /*init variables */
    for (i = 0; i < num_slices; i++)
    {
        an_done[i] = CS4224_KRAN_AN_NOT_DONE;
    }
    
    /* First reset the ASIC to ensure it is in operational state.
       This will reset the entire device. Only the upper 24 bits of the
       slice parameter are used to reference the appropriate ASIC. The
       lower 8 bits are ignored. This method should only be called once
       when the ASIC is first powered on. */
    cs4224_hard_reset(0);

    /* Setup the rules for 10G KR */
    status |= cs4224_rules_set_default(CS4224_TARGET_APPLICATION_KRAN, &rules);

    /* setup rules for the line side, EDC mode must be 10G_BP */
    rules.rx_if.dplx_line_edc_mode = CS_HSIO_EDC_MODE_10G_BP;

    /* setup rules for the host side, EDC mode must be SR */
    rules.rx_if.dplx_host_edc_mode         = CS_HSIO_EDC_MODE_SR;
    rules.rx_if.dplx_host_eq.traceloss     = CS_HSIO_TRACE_LOSS_2dB;
    rules.tx_if.dplx_host_driver.traceloss = CS_HSIO_TRACE_LOSS_2dB;

    /* advertise the following KR data-rate capabilities */
    rules.kran.data_rates       = CS4224_KRAN_DATA_RATE_10G;

    rules.kran.fec_ability_f0   = TRUE;  /* FEC ability flag (F0) */
    rules.kran.fec_requested_f1 = TRUE;  /* FEC requested flag (F1) */
    rules.kran.pause_ability_c0 = FALSE; /* Pause ability flag (C0) */
    rules.kran.pause_ability_c1 = FALSE; /* Pause ability flag (C1) */
    rules.kran.remote_fault_d13 = FALSE; /* Remote Fault flag (D13) */
    rules.kran.allow_training   = TRUE;  /* Training enable flag */
    rules.kran.wait_for_an_done = FALSE; /* Wait for KR-AN to complete flag. If this
                                            is set to TRUE then enter_operational_state_kran
                                            will block until AN + training has completed.
                                            This could block for a long time if the link
                                            does not come up right away. */
    
    /* if running on a lab setup (evaluation board) with no-loss cables, use
     * this option to preset the pre-emphasis levels. Otherwise leave it at the
     * default of FALSE */
    /* rules.kran.advanced.preset   = TRUE; */

    /* configure 'link partner' slices for KR-AN */
    status |= cs4224_slice_enter_operational_state_kran(0, &rules);
    status |= cs4224_slice_enter_operational_state_kran(7, &rules);
    
    /* configure two-pass-mode slices */
    rules.kran.advanced.two_pass_mode = TRUE;
    status |= cs4224_slice_enter_operational_state_kran(3, &rules);
    status |= cs4224_slice_enter_operational_state_kran(4, &rules);
    
    /* poll all slices for AN to complete and run post an config */
    for (i = 0; i < num_slices; i++)
    {
        /* timeout after 1 second for AN complete */
        an_done[i] = cs4224_kran_wait_for_an_with_timeout(slices[i], 1, &an_results[i]);
        
        if(an_done[i] != CS4224_KRAN_AN_DONE)
        {
            CS_TRACE(("ERROR: KRAN on slice %d did not complete\n",slices[i]));
            status |= cs4224_kran_status_summary(slices[i]);
            status |= CS_ERROR;
            return status;
        }
        else
        {
            CS_PRINTF(("KRAN good on slice %d\n",slices[i]));
            status |= cs4224_kran_init_kr_post_an(slices[i], &rules, &an_results[i]);
        }
    }

    CS_PRINTF(("\nKR-AN with two-pass-mode setup complete\n"));
    return status;
}

