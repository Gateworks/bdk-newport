/** @file example_init_fracdiv_core_gpio.c
 *****************************************************************************
 *
 * @brief
 *    This module provides an example of configuring the core fractional divider.
 *
 *****************************************************************************
 * @author
 *    Copyright (c) 2011-2015, Inphi Corporation
 *    All rights reserved.
 *    
 *    Redistribution and use in source and binary forms, with or without modification, 
 *    are permitted provided that the following conditions are met:
 *    
 *    1.	Redistributions of source code must retain the above copyright notice, 
 *       this list of conditions and the following disclaimer.
 *    
 *    2.	Redistributions in binary form must reproduce the above copyright notice, 
 *       this list of conditions and the following disclaimer in the documentation and/or 
 *       other materials provided with the distribution.
 *    
 *    3.	Neither the name of Inphi Corporation nor the names of its contributors 
 *       may be used to endorse or promote products derived from this software without 
 *       specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 *    THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 *    PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *    CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 *    PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 *    OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 *    WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 *    OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 *    ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *    API Version Number: 3.7.8
 ****************************************************************************/
#include "cs4224_api.h"

/**
 * The following example describes the process of configuring
 * the core fractional divider to generate a 25MHz tone out
 * GPIO 2
 */

cs_status example_init_fracdiv_core_gpio()
{
    cs_status status = CS_OK;
    cs_uint32 slice = 0;
    cs4224_rules_t rules;
    /*
    cs4224_gpio_cfg_t gpio_cfg;
    */

    CS_PRINTF(("Initializing the chip to use the Core Fractional Divider and to output a 25MHz tone out GPIO2\n"));

    /* We MUST reset the device into a known state as the very first thing we do. This
     * will reset the entire device, not just 'slice'.
     */
    status |= cs4224_hard_reset(slice);
    if(CS_OK != status)
    {
        CS_TRACE(("ERROR trying to reset device\n"));
        return status;
    }
    
    /* setup the default rules for 10G */
    status |= cs4224_rules_set_default(CS4224_TARGET_APPLICATION_10G, &rules);

    /* configure the data-path for 10G */
    status |= cs4224_slice_enter_operational_state(slice, &rules);

    /* The cs4224_fracdiv_core_init() method can be used to initialize the 
     * configuration of the Core Fractional Divider block. This block is used to 
     * generate a pilot tone broadcast for external use. 
     *
     * This example shows how to configure the chip to output a 25MHz tone out of
     * GPIO 2. It is assumed that the data-path is configured for 10G. 
     *
     * Note that on a duplex part, the 2nd argument (direction) must be set to identify the 
     * direction of the data-path.
     *
     * cs4224 part (simplex), 2nd argument: CS_HSIO_SPLX_DIR
     * cs4343 part (duplex),  2nd argument: one of CS_HSIO_DPLX_LINE_RX_TO_HOST_TX_DIR or
     *                                      CS_HSIO_DPLX_HOST_RX_TO_LINE_TX_DIR
     *
     * See the user guide, section under 'Calculating the SyncE Clock', for a python
     * example of how to calculate the divisor and numerator values.
     * 
     */ 
    status = cs4224_fracdiv_core_init(
                    slice,
                    CS4224_LINE_RX_TO_HOST_TX_DIR,
                    33,          /* Divisor */
                    0x900000);  /* Numerator */

    /* Configure GPIO 2 to receive the 25MHz tone from the clock monitor. The
     * clock monitor will automatically be configured to receive the tone from the Core
     * Fractional Divider 
     */
    /*cs4224_gpio_cfg_output(&gpio_cfg, CS4224_GPIO_OUT_FCN_PORT_CLKMON_CLK);
    
    cs4224_gpio_init(slice, CS4224_GPIO2, &gpio_cfg);
    */

    return status;
}

