
#include "cs4224_api.h"


cs_status cs4224_reg_set(cs_uint32 slice, cs_uint32 addr, cs_uint16 data)
{
    return CS_ERROR;
}

cs_status cs4224_reg_get(cs_uint32 slice, cs_uint32 addr, cs_uint16* data)
{
    *data = 0;

    return CS_ERROR;
}


int main(int argc, char* argv[])
{
    return 0;
}
